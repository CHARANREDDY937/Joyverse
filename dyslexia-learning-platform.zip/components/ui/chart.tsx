export const Chart = () => {
  return <div>Chart Placeholder</div>
}

export const ChartContainer = () => {
  return <div>ChartContainer Placeholder</div>
}

export const ChartTooltip = () => {
  return <div>ChartTooltip Placeholder</div>
}

export const ChartTooltipContent = () => {
  return <div>ChartTooltipContent Placeholder</div>
}

export const ChartLegend = () => {
  return <div>ChartLegend Placeholder</div>
}

export const ChartLegendContent = () => {
  return <div>ChartLegendContent Placeholder</div>
}

export const ChartStyle = () => {
  return <div>ChartStyle Placeholder</div>
}

