import { Inter } from "next/font/google"
import "./globals.css"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "PlayLearn - Dyslexia Learning Platform",
  description: "An interactive learning platform for children with dyslexia",
    generator: 'v0.dev'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className={inter.className}>
        <div className="fixed bottom-4 right-4 z-50">
          <div className="flex flex-col space-y-2">
            <Link href="/student/login">
              <Button variant="outline" className="bg-blue-500 text-white hover:bg-blue-600">
                Student Login
              </Button>
            </Link>
            <Link href="/therapist/login">
              <Button variant="outline" className="bg-yellow-500 text-white hover:bg-yellow-600">
                Therapist Login
              </Button>
            </Link>
          </div>
        </div>
        {children}
      </body>
    </html>
  )
}



import './globals.css'