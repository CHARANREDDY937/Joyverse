import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-100 to-blue-100">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-purple-700 mb-6">PlayLearn</h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8">
            An interactive learning platform for children with dyslexia
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
            <Card className="border-4 border-yellow-400 bg-white shadow-xl transform transition-all hover:scale-105">
              <CardHeader className="bg-yellow-400 text-white">
                <CardTitle className="text-2xl font-bold text-center">Therapist Login</CardTitle>
                <CardDescription className="text-white text-opacity-90 text-center">
                  For educators and therapists
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6 pb-8 px-8">
                <p className="mb-6 text-gray-700">
                  Manage students, track progress, and customize learning experiences.
                </p>
                <Link href="/therapist/login" className="block w-full">
                  <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-lg py-6">Therapist Login</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-4 border-blue-400 bg-white shadow-xl transform transition-all hover:scale-105">
              <CardHeader className="bg-blue-400 text-white">
                <CardTitle className="text-2xl font-bold text-center">Student Login</CardTitle>
                <CardDescription className="text-white text-opacity-90 text-center">For young learners</CardDescription>
              </CardHeader>
              <CardContent className="pt-6 pb-8 px-8">
                <p className="mb-6 text-gray-700">Play fun games that help improve reading and language skills.</p>
                <Link href="/student/login" className="block w-full">
                  <Button className="w-full bg-blue-500 hover:bg-blue-600 text-lg py-6">Student Login</Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <div className="mt-16 flex flex-wrap gap-4 justify-center">
            <div className="w-16 h-16 rounded-full bg-red-400 animate-bounce delay-100"></div>
            <div className="w-16 h-16 rounded-full bg-yellow-400 animate-bounce delay-200"></div>
            <div className="w-16 h-16 rounded-full bg-green-400 animate-bounce delay-300"></div>
            <div className="w-16 h-16 rounded-full bg-blue-400 animate-bounce delay-400"></div>
            <div className="w-16 h-16 rounded-full bg-purple-400 animate-bounce delay-500"></div>
          </div>
        </div>
      </div>
    </div>
  )
}

