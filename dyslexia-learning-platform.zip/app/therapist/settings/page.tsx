"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, BarChart, SettingsIcon, LogOut, Bell, Shield, Palette } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export default function TherapistSettings() {
  const [notifications, setNotifications] = useState({
    email: true,
    studentActivity: true,
    progressReports: true,
  })

  const [appearance, setAppearance] = useState({
    theme: "light",
    fontSize: "medium",
    colorScheme: "default",
  })

  const [security, setSecurity] = useState({
    twoFactor: false,
    sessionTimeout: "30",
  })

  const [profile, setProfile] = useState({
    name: "Dr. Smith",
    email: "dr.smith@example.com",
    phone: "(555) 123-4567",
    specialization: "Pediatric Dyslexia Therapy",
  })

  // Apply theme changes when appearance settings change
  useEffect(() => {
    // Apply theme
    const root = document.documentElement
    if (appearance.theme === "dark") {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }

    // Apply font size
    switch (appearance.fontSize) {
      case "small":
        root.style.fontSize = "14px"
        break
      case "medium":
        root.style.fontSize = "16px"
        break
      case "large":
        root.style.fontSize = "18px"
        break
    }

    // Apply color scheme
    switch (appearance.colorScheme) {
      case "default":
        root.style.setProperty("--primary-color", "#eab308") // yellow-500
        break
      case "blue":
        root.style.setProperty("--primary-color", "#3b82f6") // blue-500
        break
      case "green":
        root.style.setProperty("--primary-color", "#22c55e") // green-500
        break
    }

    // Save settings to localStorage
    localStorage.setItem("therapistAppearance", JSON.stringify(appearance))
  }, [appearance])

  // Load saved settings on component mount
  useEffect(() => {
    const savedAppearance = localStorage.getItem("therapistAppearance")
    if (savedAppearance) {
      setAppearance(JSON.parse(savedAppearance))
    }
  }, [])

  const handleSaveProfile = () => {
    localStorage.setItem("therapistProfile", JSON.stringify(profile))
    toast({
      title: "Profile updated",
      description: "Your profile information has been saved.",
    })
  }

  const handleSavePassword = () => {
    toast({
      title: "Password updated",
      description: "Your password has been changed successfully.",
    })
  }

  const handleResetData = () => {
    if (confirm("Are you sure you want to reset all student data? This action cannot be undone.")) {
      localStorage.removeItem("students")
      toast({
        title: "Data reset",
        description: "All student data has been reset.",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 dark:text-white">
      <div className="flex">
        {/* Sidebar */}
        <div
          className="w-64 bg-yellow-500 min-h-screen p-4 hidden md:block"
          style={{ backgroundColor: "var(--primary-color, #eab308)" }}
        >
          <div className="text-white font-bold text-xl mb-8 mt-4">PlayLearn</div>
          <nav className="space-y-2">
            <Link
              href="/therapist/dashboard"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <User size={20} />
              <span>Students</span>
            </Link>
            <Link
              href="/therapist/analytics"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <BarChart size={20} />
              <span>Analytics</span>
            </Link>
            <Link
              href="/therapist/settings"
              className="flex items-center space-x-2 bg-yellow-600 bg-opacity-50 text-white p-3 rounded-lg"
            >
              <SettingsIcon size={20} />
              <span>Settings</span>
            </Link>
            <Link
              href="/"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50 mt-8"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </Link>
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1">
          <header className="bg-white shadow-sm p-4 dark:bg-gray-800">
            <div className="container mx-auto flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Settings</h1>
              <div className="flex items-center space-x-4">
                <span className="text-gray-600 dark:text-gray-300">Welcome, Dr. Smith</span>
                <Link href="/">
                  <Button variant="outline">Logout</Button>
                </Link>
              </div>
            </div>
          </header>

          <main className="container mx-auto p-4">
            <Tabs defaultValue="profile">
              <div className="flex justify-between items-center mb-6">
                <TabsList>
                  <TabsTrigger value="profile">Profile</TabsTrigger>
                  <TabsTrigger value="notifications">Notifications</TabsTrigger>
                  <TabsTrigger value="appearance">Appearance</TabsTrigger>
                  <TabsTrigger value="security">Security</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="profile" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>Update your personal information and contact details</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={profile.name}
                          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={profile.email}
                          onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={profile.phone}
                          onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="specialization">Specialization</Label>
                        <Input
                          id="specialization"
                          value={profile.specialization}
                          onChange={(e) => setProfile({ ...profile, specialization: e.target.value })}
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={handleSaveProfile}>Save Changes</Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Change Password</CardTitle>
                    <CardDescription>Update your password to maintain account security</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={handleSavePassword}>Update Password</Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Data Management</CardTitle>
                    <CardDescription>Manage student data and platform settings</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium mb-2">Reset Student Data</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                          This will permanently delete all student data and performance records. This action cannot be
                          undone.
                        </p>
                        <Button variant="destructive" onClick={handleResetData}>
                          Reset All Data
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notifications" className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Bell className="h-5 w-5 text-yellow-500" style={{ color: "var(--primary-color, #eab308)" }} />
                      <CardTitle>Notification Preferences</CardTitle>
                    </div>
                    <CardDescription>Control how and when you receive notifications</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Email Notifications</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Receive notifications via email</p>
                      </div>
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, email: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Student Activity</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Get notified when students complete games
                        </p>
                      </div>
                      <Switch
                        checked={notifications.studentActivity}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, studentActivity: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Weekly Progress Reports</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Receive weekly summaries of student progress
                        </p>
                      </div>
                      <Switch
                        checked={notifications.progressReports}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, progressReports: checked })}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      onClick={() => {
                        localStorage.setItem("therapistNotifications", JSON.stringify(notifications))
                        toast({ title: "Notification settings saved" })
                      }}
                    >
                      Save Preferences
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="appearance" className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Palette className="h-5 w-5 text-yellow-500" style={{ color: "var(--primary-color, #eab308)" }} />
                      <CardTitle>Appearance Settings</CardTitle>
                    </div>
                    <CardDescription>Customize how the platform looks</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label>Theme</Label>
                      <div className="grid grid-cols-3 gap-2">
                        <Button
                          variant={appearance.theme === "light" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, theme: "light" })}
                        >
                          <div className="w-8 h-8 rounded-full bg-white border border-gray-300 mb-2"></div>
                          <span>Light</span>
                        </Button>
                        <Button
                          variant={appearance.theme === "dark" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, theme: "dark" })}
                        >
                          <div className="w-8 h-8 rounded-full bg-gray-800 border border-gray-600 mb-2"></div>
                          <span>Dark</span>
                        </Button>
                        <Button
                          variant={appearance.theme === "system" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, theme: "system" })}
                        >
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-white to-gray-800 border border-gray-300 mb-2"></div>
                          <span>System</span>
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Font Size</Label>
                      <div className="grid grid-cols-3 gap-2">
                        <Button
                          variant={appearance.fontSize === "small" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, fontSize: "small" })}
                        >
                          <span className="text-sm">Small</span>
                        </Button>
                        <Button
                          variant={appearance.fontSize === "medium" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, fontSize: "medium" })}
                        >
                          <span className="text-base">Medium</span>
                        </Button>
                        <Button
                          variant={appearance.fontSize === "large" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, fontSize: "large" })}
                        >
                          <span className="text-lg">Large</span>
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Color Scheme</Label>
                      <div className="grid grid-cols-3 gap-2">
                        <Button
                          variant={appearance.colorScheme === "default" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, colorScheme: "default" })}
                          style={{ backgroundColor: appearance.colorScheme === "default" ? "#eab308" : "" }}
                        >
                          <div className="w-8 h-8 rounded-full bg-yellow-500 mb-2"></div>
                          <span>Default</span>
                        </Button>
                        <Button
                          variant={appearance.colorScheme === "blue" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, colorScheme: "blue" })}
                          style={{ backgroundColor: appearance.colorScheme === "blue" ? "#3b82f6" : "" }}
                        >
                          <div className="w-8 h-8 rounded-full bg-blue-500 mb-2"></div>
                          <span>Blue</span>
                        </Button>
                        <Button
                          variant={appearance.colorScheme === "green" ? "default" : "outline"}
                          className="flex flex-col items-center justify-center p-4"
                          onClick={() => setAppearance({ ...appearance, colorScheme: "green" })}
                          style={{ backgroundColor: appearance.colorScheme === "green" ? "#22c55e" : "" }}
                        >
                          <div className="w-8 h-8 rounded-full bg-green-500 mb-2"></div>
                          <span>Green</span>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => toast({ title: "Appearance settings saved" })}>Save Preferences</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="security" className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-yellow-500" style={{ color: "var(--primary-color, #eab308)" }} />
                      <CardTitle>Security Settings</CardTitle>
                    </div>
                    <CardDescription>Manage your account security preferences</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Two-Factor Authentication</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Add an extra layer of security to your account
                        </p>
                      </div>
                      <Switch
                        checked={security.twoFactor}
                        onCheckedChange={(checked) => setSecurity({ ...security, twoFactor: checked })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                      <Input
                        id="session-timeout"
                        type="number"
                        value={security.sessionTimeout}
                        onChange={(e) => setSecurity({ ...security, sessionTimeout: e.target.value })}
                      />
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Your account will be automatically logged out after this period of inactivity
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      onClick={() => {
                        localStorage.setItem("therapistSecurity", JSON.stringify(security))
                        toast({ title: "Security settings saved" })
                      }}
                    >
                      Save Settings
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}

