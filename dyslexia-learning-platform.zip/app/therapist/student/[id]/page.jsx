"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, User, BarChart, Settings, LogOut, MessageCircle } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

export default function StudentDetails() {
  const params = useParams()
  const router = useRouter()
  const [student, setStudent] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false)
  const [message, setMessage] = useState("")

  useEffect(() => {
    // Load student data from localStorage
    const loadStudent = () => {
      setIsLoading(true)
      try {
        const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
        const foundStudent = storedStudents.find((s) => s.id.toString() === params.id)

        if (foundStudent) {
          setStudent(foundStudent)
        } else {
          toast({
            title: "Student not found",
            description: "The requested student could not be found.",
            variant: "destructive",
          })
          router.push("/therapist/dashboard")
        }
      } catch (error) {
        console.error("Error loading student:", error)
        toast({
          title: "Error",
          description: "There was an error loading the student data.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadStudent()
  }, [params.id, router])

  const handleSendMessage = () => {
    if (!message.trim() || !student) return

    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const updatedStudents = storedStudents.map((s) => {
      if (s.id === student.id) {
        const messages = s.messages || []
        return {
          ...s,
          messages: [
            ...messages,
            {
              id: Date.now(),
              text: message,
              date: new Date().toISOString(),
              from: "therapist",
            },
          ],
        }
      }
      return s
    })

    localStorage.setItem("students", JSON.stringify(updatedStudents))

    // Update local state
    setStudent({
      ...student,
      messages: [
        ...(student.messages || []),
        {
          id: Date.now(),
          text: message,
          date: new Date().toISOString(),
          from: "therapist",
        },
      ],
    })

    toast({
      title: "Message sent",
      description: `Message sent to ${student.name}`,
    })

    setMessage("")
    setIsMessageDialogOpen(false)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-500 dark:text-gray-400">Loading student data...</p>
        </div>
      </div>
    )
  }

  if (!student) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-gray-700 dark:text-gray-300">Student not found</p>
          <Link href="/therapist/dashboard">
            <Button className="mt-4">Return to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  const gameNames = {
    "word-builder": "Word Builder",
    "memory-matching": "Memory Matching",
    "sound-match": "Sound Match",
    "rhyme-time": "Rhyme Time",
    "word-scramble": "Word Scramble",
    "spell-bee": "Spell Bee",
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 dark:text-white">
      <div className="flex">
        {/* Sidebar */}
        <div
          className="w-64 min-h-screen p-4 hidden md:block"
          style={{ backgroundColor: "var(--primary-color, #eab308)" }}
        >
          <div className="text-white font-bold text-xl mb-8 mt-4">PlayLearn</div>
          <nav className="space-y-2">
            <Link
              href="/therapist/dashboard"
              className="flex items-center space-x-2 bg-yellow-600 bg-opacity-50 text-white p-3 rounded-lg"
            >
              <User size={20} />
              <span>Students</span>
            </Link>
            <Link
              href="/therapist/analytics"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <BarChart size={20} />
              <span>Analytics</span>
            </Link>
            <Link
              href="/therapist/settings"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <Settings size={20} />
              <span>Settings</span>
            </Link>
            <Link
              href="/"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50 mt-8"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </Link>
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1">
          <header className="bg-white shadow-sm p-4 dark:bg-gray-800">
            <div className="container mx-auto flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <Link href="/therapist/dashboard">
                  <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-6 w-6" />
                  </Button>
                </Link>
                <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Student Details</h1>
              </div>
              <div className="flex items-center space-x-4">
                <Dialog open={isMessageDialogOpen} onOpenChange={setIsMessageDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Send Message
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Message to {student.name}</DialogTitle>
                      <DialogDescription>This message will be visible to the student.</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-1 items-center gap-4">
                        <Label htmlFor="message">Message</Label>
                        <textarea
                          id="message"
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          className="w-full h-32 p-2 border rounded-md"
                          placeholder="Type your message here..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit" onClick={handleSendMessage}>
                        Send Message
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </header>

          <main className="container mx-auto p-4">
            <div className="mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Student Profile</CardTitle>
                  <CardDescription>Basic information about {student.name}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Name</p>
                      <p className="font-medium">{student.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Age</p>
                      <p className="font-medium">{student.age}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Username</p>
                      <p className="font-medium">{student.username}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Level</p>
                      <p className="font-medium">{student.level}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Last Active</p>
                      <p className="font-medium">{student.lastActive}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Overall Progress</p>
                      <div className="flex items-center space-x-2">
                        <Progress value={student.progress} className="h-2 flex-1" />
                        <span className="text-sm font-medium">{student.progress}%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="performance">
              <TabsList>
                <TabsTrigger value="performance">Performance</TabsTrigger>
                <TabsTrigger value="messages">Messages</TabsTrigger>
              </TabsList>

              <TabsContent value="performance" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Game Performance</CardTitle>
                    <CardDescription>Performance metrics across all games</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {Object.entries(student.gamePerformance || {}).map(([gameId, data]) => (
                        <div key={gameId}>
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-medium">{gameNames[gameId]}</h3>
                            <div className="flex items-center space-x-4">
                              <span className="text-sm text-gray-500 dark:text-gray-400">
                                Played: {data.played} times
                              </span>
                              <span className="text-sm text-gray-500 dark:text-gray-400">Level: {data.level}</span>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Score</span>
                              <span>{data.score} points</span>
                            </div>
                            <Progress
                              value={data.played > 0 ? Math.min(100, data.score / (data.played * 10)) : 0}
                              className="h-2"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle>Emotion Analysis</CardTitle>
                    <CardDescription>Emotional responses during gameplay</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {student && (
                      <>
                        <div className="mb-6">
                          <h3 className="text-lg font-medium mb-2">Emotion Distribution</h3>
                          <div className="grid grid-cols-5 gap-2">
                            {["happy", "neutral", "sad", "surprised", "angry"].map((emotion) => {
                              // Calculate percentage based on stored emotion data
                              const emotionData = JSON.parse(localStorage.getItem(`emotionData_${student.id}`) || "[]")
                              const count = emotionData.filter((data) => data.emotion === emotion).length
                              const percentage =
                                emotionData.length > 0 ? Math.round((count / emotionData.length) * 100) : 0

                              // Get emotion color and emoji
                              const getEmotionColor = (emotion) => {
                                switch (emotion) {
                                  case "happy":
                                    return "bg-green-500"
                                  case "sad":
                                    return "bg-blue-500"
                                  case "angry":
                                    return "bg-red-500"
                                  case "surprised":
                                    return "bg-purple-500"
                                  default:
                                    return "bg-gray-500"
                                }
                              }

                              const getEmotionEmoji = (emotion) => {
                                switch (emotion) {
                                  case "happy":
                                    return "😊"
                                  case "sad":
                                    return "😢"
                                  case "angry":
                                    return "😠"
                                  case "surprised":
                                    return "😲"
                                  default:
                                    return "😐"
                                }
                              }

                              return (
                                <div key={emotion} className="flex flex-col items-center">
                                  <div className="text-2xl mb-1">{getEmotionEmoji(emotion)}</div>
                                  <div className="w-full bg-gray-200 rounded-full h-4 mb-1">
                                    <div
                                      className={`h-4 rounded-full ${getEmotionColor(emotion)}`}
                                      style={{ width: `${percentage}%` }}
                                    ></div>
                                  </div>
                                  <div className="text-xs text-gray-500 capitalize">
                                    {emotion}: {percentage}%
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                        </div>

                        <div>
                          <h3 className="text-lg font-medium mb-2">Emotion Intensity by Game</h3>
                          <div className="space-y-4">
                            {Object.keys(student.gamePerformance || {}).map((gameId) => {
                              // Calculate average intensity for this game
                              const emotionData = JSON.parse(localStorage.getItem(`emotionData_${student.id}`) || "[]")
                              const gameEmotions = emotionData.filter((data) => data.gameId === gameId)
                              const avgIntensity =
                                gameEmotions.length > 0
                                  ? Math.round(
                                      gameEmotions.reduce((sum, data) => sum + data.intensity, 0) / gameEmotions.length,
                                    )
                                  : 0

                              // Get game name
                              const gameNames = {
                                "word-builder": "Word Builder",
                                "memory-matching": "Memory Matching",
                                "sound-match": "Sound Match",
                                "rhyme-time": "Rhyme Time",
                                "word-scramble": "Word Scramble",
                                "spell-bee": "Spell Bee",
                              }

                              return (
                                <div key={gameId}>
                                  <div className="flex justify-between mb-1">
                                    <span>{gameNames[gameId] || gameId}</span>
                                    <span>Intensity: {avgIntensity}%</span>
                                  </div>
                                  <div className="w-full bg-gray-200 rounded-full h-2">
                                    <div
                                      className="h-2 rounded-full bg-blue-500"
                                      style={{ width: `${avgIntensity}%` }}
                                    ></div>
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                        </div>

                        <div className="mt-6 p-4 bg-yellow-50 rounded-lg">
                          <h3 className="font-medium flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 text-yellow-500 mr-2"
                              viewBox="0 0 20 20"
                              fill="currentColor"
                            >
                              <path
                                fillRule="evenodd"
                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                clipRule="evenodd"
                              />
                            </svg>
                            Emotion Analysis Insights
                          </h3>
                          <p className="text-sm text-gray-600 mt-2">
                            Emotion tracking helps identify when students are engaged, frustrated, or confused. Use this
                            data to personalize learning strategies and provide timely support.
                          </p>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="messages" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Messages</CardTitle>
                    <CardDescription>Communication with {student.name}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!student.messages || student.messages.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>No messages yet.</p>
                        <p>Use the "Send Message" button to start a conversation.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {student.messages.map((msg) => (
                          <div
                            key={msg.id}
                            className={`p-3 rounded-lg ${
                              msg.from === "therapist"
                                ? "bg-blue-100 dark:bg-blue-900 ml-8"
                                : "bg-gray-100 dark:bg-gray-800 mr-8"
                            }`}
                          >
                            <div className="flex justify-between items-center mb-1">
                              <span className="font-medium">{msg.from === "therapist" ? "You" : student.name}</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {new Date(msg.date).toLocaleString()}
                              </span>
                            </div>
                            <p>{msg.text}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}

