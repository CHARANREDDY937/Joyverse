"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, BarChart, Settings, LogOut } from "lucide-react"

export default function TherapistAnalytics() {
  const [students, setStudents] = useState([])
  const [activeTab, setActiveTab] = useState("overview")

  useEffect(() => {
    // Load students from localStorage
    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    setStudents(storedStudents)
  }, [])

  // Load appearance settings
  useEffect(() => {
    const savedAppearance = localStorage.getItem("therapistAppearance")
    if (savedAppearance) {
      const appearance = JSON.parse(savedAppearance)

      // Apply theme
      const root = document.documentElement
      if (appearance.theme === "dark") {
        root.classList.add("dark")
      } else {
        root.classList.remove("dark")
      }

      // Apply color scheme
      switch (appearance.colorScheme) {
        case "default":
          root.style.setProperty("--primary-color", "#eab308") // yellow-500
          break
        case "blue":
          root.style.setProperty("--primary-color", "#3b82f6") // blue-500
          break
        case "green":
          root.style.setProperty("--primary-color", "#22c55e") // green-500
          break
      }
    }
  }, [])

  // Calculate average progress across all students
  const calculateAverageProgress = () => {
    if (students.length === 0) return 0
    const totalProgress = students.reduce((sum, student) => sum + student.progress, 0)
    return Math.round(totalProgress / students.length)
  }

  // Count active students (those who have played at least one game)
  const countActiveStudents = () => {
    return students.filter((student) => Object.values(student.gamePerformance || {}).some((game) => game.played > 0))
      .length
  }

  // Find the most popular game
  const findMostPopularGame = () => {
    if (students.length === 0) return "None"

    const gameCounts = {
      "word-builder": 0,
      "memory-matching": 0,
      "sound-match": 0,
      "rhyme-time": 0,
      "word-scramble": 0,
      "spell-bee": 0,
    }

    students.forEach((student) => {
      if (student.gamePerformance) {
        Object.entries(student.gamePerformance).forEach(([game, data]) => {
          gameCounts[game] += data.played
        })
      }
    })

    const mostPlayed = Object.entries(gameCounts).sort((a, b) => b[1] - a[1])[0]

    if (mostPlayed[1] === 0) return "None"

    const gameNames = {
      "word-builder": "Word Builder",
      "memory-matching": "Memory Matching",
      "sound-match": "Sound Match",
      "rhyme-time": "Rhyme Time",
      "word-scramble": "Word Scramble",
      "spell-bee": "Spell Bee",
    }

    return gameNames[mostPlayed[0]]
  }

  // Calculate game performance percentages
  const calculateGamePerformance = () => {
    const games = ["word-builder", "memory-matching", "sound-match", "rhyme-time", "word-scramble", "spell-bee"]
    const gameNames = {
      "word-builder": "Word Builder",
      "memory-matching": "Memory Matching",
      "sound-match": "Sound Match",
      "rhyme-time": "Rhyme Time",
      "word-scramble": "Word Scramble",
      "spell-bee": "Spell Bee",
    }

    return games.map((game) => {
      let totalScore = 0
      let totalPlayed = 0

      students.forEach((student) => {
        if (student.gamePerformance && student.gamePerformance[game]) {
          totalScore += student.gamePerformance[game].score
          totalPlayed += student.gamePerformance[game].played
        }
      })

      const percentage = totalPlayed > 0 ? Math.round((totalScore / (totalPlayed * 100)) * 100) : 0

      return {
        name: gameNames[game],
        percentage,
        played: totalPlayed,
      }
    })
  }

  // Prepare data for charts
  // const prepareChartData = () => {
  //   if (students.length === 0) {
  //     return {
  //       labels: ["No Data"],
  //       datasets: [
  //         {
  //           data: [100],
  //           backgroundColor: ["#e5e7eb"],
  //         },
  //       ],
  //     }
  //   }

  //   const gamePerformance = calculateGamePerformance()

  //   return {
  //     labels: gamePerformance.map((game) => game.name),
  //     datasets: [
  //       {
  //         data: gamePerformance.map((game) => game.percentage),
  //         backgroundColor: [
  //           "#4ade80", // green
  //           "#a78bfa", // purple
  //           "#60a5fa", // blue
  //           "#f87171", // red
  //           "#facc15", // yellow
  //           "#f97316", // orange
  //         ],
  //       },
  //     ],
  //   }
  // }

  // Prepare student progress data
  // const prepareStudentProgressData = () => {
  //   if (students.length === 0) {
  //     return {
  //       labels: ["No Students"],
  //       datasets: [
  //         {
  //           label: "Progress",
  //           data: [0],
  //           backgroundColor: "#e5e7eb",
  //         },
  //       ],
  //     }
  //   }

  //   return {
  //     labels: students.map((student) => student.name),
  //     datasets: [
  //       {
  //         label: "Progress",
  //         data: students.map((student) => student.progress),
  //         backgroundColor: "#60a5fa",
  //       },
  //     ],
  //   }
  // }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 dark:text-white">
      <div className="flex">
        {/* Sidebar */}
        <div
          className="w-64 min-h-screen p-4 hidden md:block"
          style={{ backgroundColor: "var(--primary-color, #eab308)" }}
        >
          <div className="text-white font-bold text-xl mb-8 mt-4">PlayLearn</div>
          <nav className="space-y-2">
            <Link
              href="/therapist/dashboard"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <User size={20} />
              <span>Students</span>
            </Link>
            <Link
              href="/therapist/analytics"
              className="flex items-center space-x-2 bg-yellow-600 bg-opacity-50 text-white p-3 rounded-lg"
            >
              <BarChart size={20} />
              <span>Analytics</span>
            </Link>
            <Link
              href="/therapist/settings"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <Settings size={20} />
              <span>Settings</span>
            </Link>
            <Link
              href="/"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50 mt-8"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </Link>
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1">
          <header className="bg-white shadow-sm p-4 dark:bg-gray-800">
            <div className="container mx-auto flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Analytics Dashboard</h1>
              <div className="flex items-center space-x-4">
                <span className="text-gray-600 dark:text-gray-300">Welcome, Dr. Smith</span>
                <Link href="/">
                  <Button variant="outline">Logout</Button>
                </Link>
              </div>
            </div>
          </header>

          <main className="container mx-auto p-4">
            <Tabs defaultValue="overview" onValueChange={setActiveTab} value={activeTab}>
              <div className="flex justify-between items-center mb-6">
                <TabsList>
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="games">Games</TabsTrigger>
                  <TabsTrigger value="students">Students</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Overview</CardTitle>
                    <CardDescription>Summary of student performance across all games</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {students.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p className="mb-4">No performance data available yet.</p>
                        <p>Add students and have them play games to generate analytics.</p>
                      </div>
                    ) : (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium">Average Progress</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">{calculateAverageProgress()}%</div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium">Active Students</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                {countActiveStudents()}/{students.length}
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium">Most Popular Game</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">{findMostPopularGame()}</div>
                            </CardContent>
                          </Card>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Game Performance</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="h-80 flex items-center justify-center">
                                <div className="text-center text-gray-500 dark:text-gray-400">
                                  <p>Game performance visualization</p>
                                  <p className="text-sm">(Chart visualization would appear here)</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Student Progress</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="h-80 flex items-center justify-center">
                                <div className="text-center text-gray-500 dark:text-gray-400">
                                  <p>Student progress visualization</p>
                                  <p className="text-sm">(Chart visualization would appear here)</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="games" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Game Analytics</CardTitle>
                    <CardDescription>Detailed performance metrics for each game</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {students.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>No game data available yet. Students need to play games to generate analytics.</p>
                      </div>
                    ) : (
                      <div className="space-y-8">
                        {calculateGamePerformance().map((game) => (
                          <div key={game.name} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <h3 className="font-medium">{game.name}</h3>
                              <div className="text-sm text-gray-500 dark:text-gray-400">Played {game.played} times</div>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Performance</span>
                              <span>{game.percentage}%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                              <div
                                className="h-2.5 rounded-full"
                                style={{
                                  width: `${game.percentage}%`,
                                  backgroundColor: "var(--primary-color, #eab308)",
                                }}
                              ></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="students" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Student Analytics</CardTitle>
                    <CardDescription>Individual performance metrics for each student</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {students.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p>No students added yet. Add students from the dashboard to see analytics.</p>
                      </div>
                    ) : (
                      <div className="space-y-8">
                        {students.map((student) => (
                          <Card key={student.id} className="p-4">
                            <div className="flex justify-between items-center mb-4">
                              <h3 className="font-bold text-lg">{student.name}</h3>
                              <div className="text-sm bg-blue-100 dark:bg-blue-900 px-2 py-1 rounded-full">
                                Level {student.level}
                              </div>
                            </div>

                            <div className="space-y-1 mb-4">
                              <div className="flex justify-between text-sm">
                                <span>Overall Progress</span>
                                <span>{student.progress}%</span>
                              </div>
                              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                <div
                                  className="h-2 rounded-full"
                                  style={{
                                    width: `${student.progress}%`,
                                    backgroundColor: "var(--primary-color, #eab308)",
                                  }}
                                ></div>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {student.gamePerformance &&
                                Object.entries(student.gamePerformance).map(([gameId, data]) => {
                                  const gameNames = {
                                    "word-builder": "Word Builder",
                                    "memory-matching": "Memory Matching",
                                    "sound-match": "Sound Match",
                                    "rhyme-time": "Rhyme Time",
                                    "word-scramble": "Word Scramble",
                                    "spell-bee": "Spell Bee",
                                  }

                                  const gameName = gameNames[gameId]
                                  const percentage =
                                    data.played > 0 ? Math.round((data.score / (data.played * 100)) * 100) : 0

                                  return (
                                    <div key={gameId} className="space-y-1">
                                      <div className="flex justify-between text-sm">
                                        <span>{gameName}</span>
                                        <span>{data.played > 0 ? `${percentage}%` : "Not played"}</span>
                                      </div>
                                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                                        <div
                                          className="h-1.5 rounded-full"
                                          style={{
                                            width: `${percentage}%`,
                                            backgroundColor: "var(--primary-color, #eab308)",
                                          }}
                                        ></div>
                                      </div>
                                    </div>
                                  )
                                })}
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}

