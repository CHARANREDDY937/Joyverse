"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/hooks/use-toast"

export default function TherapistLogin() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // For demo purposes, we'll check against the stored therapists
      await new Promise((resolve) => setTimeout(resolve, 1000))

      console.log("Attempting therapist login with:", { email })

      // Get therapists from localStorage
      let storedTherapists = JSON.parse(localStorage.getItem("therapists") || "[]")
      console.log("Initial stored therapists:", storedTherapists)

      // Add a default therapist if none exists for testing
      if (storedTherapists.length === 0) {
        const defaultTherapist = {
          id: 1,
          name: "Dr. Smith",
          email: "therapist@example.com",
          password: "password",
          specialization: "Pediatric Dyslexia Therapy",
          experience: "10",
          assignedStudents: [1],
          dateRegistered: new Date().toISOString(),
          lastActive: new Date().toISOString(),
        }
        storedTherapists = [defaultTherapist]
        localStorage.setItem("therapists", JSON.stringify(storedTherapists))

        console.log("Added default therapist:", defaultTherapist)
      }

      // Find therapist with matching email
      const therapist = storedTherapists.find((t) => t.email === email)

      if (!therapist) {
        console.log("Therapist not found with email:", email)
        throw new Error("Therapist not found. Please check your email.")
      }

      // Check password
      if (therapist.password !== password) {
        console.log("Password doesn't match for therapist:", email)
        throw new Error("Incorrect password. Please try again.")
      }

      // Update last active time
      const updatedTherapists = storedTherapists.map((t) => {
        if (t.email === email) {
          return {
            ...t,
            lastActive: new Date().toISOString(),
          }
        }
        return t
      })
      localStorage.setItem("therapists", JSON.stringify(updatedTherapists))

      // Store current therapist ID for session
      localStorage.setItem("currentTherapist", therapist.id)

      toast({
        title: "Login successful",
        description: `Welcome back, ${therapist.name}!`,
      })

      // Navigate to dashboard
      router.push("/therapist/dashboard")
    } catch (error) {
      console.error("Login error:", error)
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Please check your login details",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-100 to-orange-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-4 border-yellow-400 shadow-2xl">
        <CardHeader className="bg-yellow-400 text-white">
          <CardTitle className="text-2xl font-bold text-center">Therapist Login</CardTitle>
          <CardDescription className="text-white text-opacity-90 text-center">
            Access your dashboard to manage students
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-12"
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-yellow-500 hover:bg-yellow-600 h-12 text-lg"
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600 mb-2">Demo credentials:</p>
            <p className="text-sm text-gray-500">Email: therapist@example.com</p>
            <p className="text-sm text-gray-500">Password: password</p>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <div className="text-sm text-center text-gray-500">
            <Link href="/forgot-password" className="text-yellow-600 hover:underline">
              Forgot password?
            </Link>
          </div>
          <div className="text-sm text-center text-gray-500">
            Don&apos;t have an account?{" "}
            <Link href="/therapist/register" className="text-yellow-600 hover:underline">
              Register
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

