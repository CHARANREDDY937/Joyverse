"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/hooks/use-toast"
import { PlusCircle, User, BarChart, Settings, LogOut, MessageCircle, Bell } from "lucide-react"

export default function TherapistDashboard() {
  const [students, setStudents] = useState([])
  const [newStudent, setNewStudent] = useState({ name: "", age: "", username: "", password: "" })
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [message, setMessage] = useState("")
  const [currentTherapist, setCurrentTherapist] = useState(null)
  const [unreadMessages, setUnreadMessages] = useState([])
  const [showMessageNotification, setShowMessageNotification] = useState(false)
  const router = useRouter()

  // Load therapist and students data
  useEffect(() => {
    const therapistId = localStorage.getItem("currentTherapist")
    if (!therapistId) {
      router.push("/therapist/login")
      return
    }

    const therapists = JSON.parse(localStorage.getItem("therapists") || "[]")
    const therapist = therapists.find((t) => t.id.toString() === therapistId.toString())

    if (!therapist) {
      router.push("/therapist/login")
      return
    }

    setCurrentTherapist(therapist)

    // Load all students
    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    setStudents(storedStudents)

    // Check for unread messages from students
    const messages = []
    storedStudents.forEach((student) => {
      if (student.messages && student.messages.length > 0) {
        const studentMessages = student.messages.filter((msg) => msg.from === "student" && !msg.read)
        if (studentMessages.length > 0) {
          messages.push({
            studentId: student.id,
            studentName: student.name,
            count: studentMessages.length,
          })
        }
      }
    })

    setUnreadMessages(messages)
    setShowMessageNotification(messages.length > 0)
  }, [router])

  const handleAddStudent = () => {
    // Validate inputs
    if (!newStudent.name || !newStudent.age || !newStudent.username || !newStudent.password) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    // Add new student with empty performance data
    const newId = students.length > 0 ? Math.max(...students.map((s) => s.id)) + 1 : 1
    const studentToAdd = {
      id: newId,
      name: newStudent.name,
      age: Number.parseInt(newStudent.age),
      username: newStudent.username,
      password: newStudent.password,
      level: 1,
      lastActive: "Never",
      progress: 0,
      messages: [],
      gamePerformance: {
        "word-builder": { played: 0, score: 0, level: 1 },
        "memory-matching": { played: 0, score: 0, level: 1 },
        "sound-match": { played: 0, score: 0, level: 1 },
        "rhyme-time": { played: 0, score: 0, level: 1 },
        "word-scramble": { played: 0, score: 0, level: 1 },
        "spell-bee": { played: 0, score: 0, level: 1 },
      },
    }

    setStudents([...students, studentToAdd])
    setNewStudent({ name: "", age: "", username: "", password: "" })
    setIsDialogOpen(false)

    // Store in localStorage for persistence
    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    localStorage.setItem("students", JSON.stringify([...storedStudents, studentToAdd]))

    // Assign student to current therapist
    if (currentTherapist) {
      const therapists = JSON.parse(localStorage.getItem("therapists") || "[]")
      const updatedTherapists = therapists.map((t) => {
        if (t.id === currentTherapist.id) {
          return {
            ...t,
            assignedStudents: [...(t.assignedStudents || []), newId],
          }
        }
        return t
      })

      localStorage.setItem("therapists", JSON.stringify(updatedTherapists))
      setCurrentTherapist({
        ...currentTherapist,
        assignedStudents: [...(currentTherapist.assignedStudents || []), newId],
      })
    }

    toast({
      title: "Student added",
      description: `${newStudent.name} has been added successfully. Credentials: ${newStudent.username} / ${newStudent.password}`,
    })
  }

  const handleSendMessage = () => {
    if (!message.trim() || !selectedStudent) return

    const updatedStudents = students.map((student) => {
      if (student.id === selectedStudent.id) {
        const messages = student.messages || []
        return {
          ...student,
          messages: [
            ...messages,
            {
              id: Date.now(),
              text: message,
              date: new Date().toISOString(),
              from: "therapist",
            },
          ],
        }
      }
      return student
    })

    setStudents(updatedStudents)
    localStorage.setItem("students", JSON.stringify(updatedStudents))

    toast({
      title: "Message sent",
      description: `Message sent to ${selectedStudent.name}`,
    })

    setMessage("")
    setIsMessageDialogOpen(false)
  }

  // Navigate to student details page
  const viewStudentDetails = (student) => {
    // Mark all messages from this student as read
    if (student.messages && student.messages.length > 0) {
      const updatedStudents = students.map((s) => {
        if (s.id === student.id) {
          const updatedMessages = s.messages.map((msg) => {
            if (msg.from === "student") {
              return { ...msg, read: true }
            }
            return msg
          })

          return {
            ...s,
            messages: updatedMessages,
          }
        }
        return s
      })

      setStudents(updatedStudents)
      localStorage.setItem("students", JSON.stringify(updatedStudents))

      // Update unread messages count
      setUnreadMessages(unreadMessages.filter((msg) => msg.studentId !== student.id))
      if (unreadMessages.length <= 1) {
        setShowMessageNotification(false)
      }
    }

    setSelectedStudent(student)
    router.push(`/therapist/student/${student.id}`)
  }

  const handleLogout = () => {
    localStorage.removeItem("currentTherapist")
    router.push("/therapist/login")
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 dark:text-white">
      <div className="flex">
        {/* Sidebar */}
        <div
          className="w-64 min-h-screen p-4 hidden md:block"
          style={{ backgroundColor: "var(--primary-color, #eab308)" }}
        >
          <div className="text-white font-bold text-xl mb-8 mt-4">PlayLearn</div>
          <nav className="space-y-2">
            <Link
              href="/therapist/dashboard"
              className="flex items-center space-x-2 bg-yellow-600 bg-opacity-50 text-white p-3 rounded-lg"
            >
              <User size={20} />
              <span>Students</span>
            </Link>
            <Link
              href="/therapist/analytics"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <BarChart size={20} />
              <span>Analytics</span>
            </Link>
            <Link
              href="/therapist/settings"
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50"
            >
              <Settings size={20} />
              <span>Settings</span>
            </Link>
            <Button
              onClick={handleLogout}
              className="flex items-center space-x-2 text-white p-3 rounded-lg hover:bg-yellow-600 hover:bg-opacity-50 mt-8 w-full justify-start"
              variant="ghost"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </Button>
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1">
          <header className="bg-white shadow-sm p-4 dark:bg-gray-800">
            <div className="container mx-auto flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Therapist Dashboard</h1>
              <div className="flex items-center space-x-4">
                {showMessageNotification && (
                  <div className="relative">
                    <Bell className="h-6 w-6 text-yellow-500 animate-pulse" />
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {unreadMessages.reduce((total, msg) => total + msg.count, 0)}
                    </span>
                    <div className="absolute top-full right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 z-10">
                      <h3 className="font-medium mb-2">Unread Messages</h3>
                      <ul className="space-y-2">
                        {unreadMessages.map((msg) => (
                          <li key={msg.studentId} className="text-sm">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start text-left"
                              onClick={() => viewStudentDetails(students.find((s) => s.id === msg.studentId))}
                            >
                              <MessageCircle className="h-4 w-4 mr-2 text-blue-500" />
                              {msg.studentName} ({msg.count})
                            </Button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
                <span className="text-gray-600 dark:text-gray-300">
                  Welcome, {currentTherapist?.name || "Dr. Smith"}
                </span>
                <Button variant="outline" onClick={handleLogout}>
                  Logout
                </Button>
              </div>
            </div>
          </header>

          <main className="container mx-auto p-4">
            <Tabs defaultValue="students">
              <div className="flex justify-between items-center mb-6">
                <TabsList>
                  <TabsTrigger value="students">Students</TabsTrigger>
                  <TabsTrigger value="performance">Performance</TabsTrigger>
                  <TabsTrigger value="messages">Messages</TabsTrigger>
                </TabsList>

                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button style={{ backgroundColor: "var(--primary-color, #eab308)" }} className="hover:opacity-90">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Add Student
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Student</DialogTitle>
                      <DialogDescription>
                        Create a new student account and generate login credentials.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="name" className="text-right">
                          Name
                        </Label>
                        <Input
                          id="name"
                          value={newStudent.name}
                          onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="age" className="text-right">
                          Age
                        </Label>
                        <Input
                          id="age"
                          type="number"
                          value={newStudent.age}
                          onChange={(e) => setNewStudent({ ...newStudent, age: e.target.value })}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="username" className="text-right">
                          Username
                        </Label>
                        <Input
                          id="username"
                          value={newStudent.username}
                          onChange={(e) => setNewStudent({ ...newStudent, username: e.target.value })}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="password" className="text-right">
                          Password
                        </Label>
                        <Input
                          id="password"
                          value={newStudent.password}
                          onChange={(e) => setNewStudent({ ...newStudent, password: e.target.value })}
                          className="col-span-3"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit" onClick={handleAddStudent}>
                        Add Student
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Message Dialog */}
                <Dialog open={isMessageDialogOpen} onOpenChange={setIsMessageDialogOpen}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Message to {selectedStudent?.name}</DialogTitle>
                      <DialogDescription>This message will be visible to the student.</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-1 items-center gap-4">
                        <Label htmlFor="message">Message</Label>
                        <textarea
                          id="message"
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          className="w-full h-32 p-2 border rounded-md"
                          placeholder="Type your message here..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit" onClick={handleSendMessage}>
                        Send Message
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>

              <TabsContent value="students" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Student Management</CardTitle>
                    <CardDescription>Manage your students and their learning progress</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {students.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p className="mb-4">No students added yet.</p>
                        <p>Click the "Add Student" button to get started.</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Age</TableHead>
                            <TableHead>Username</TableHead>
                            <TableHead>Level</TableHead>
                            <TableHead>Last Active</TableHead>
                            <TableHead>Progress</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {students.map((student) => (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">
                                {student.name}
                                {unreadMessages.some((msg) => msg.studentId === student.id) && (
                                  <span className="ml-2 inline-block bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                    {unreadMessages.find((msg) => msg.studentId === student.id).count}
                                  </span>
                                )}
                              </TableCell>
                              <TableCell>{student.age}</TableCell>
                              <TableCell>{student.username}</TableCell>
                              <TableCell>Level {student.level}</TableCell>
                              <TableCell>{student.lastActive}</TableCell>
                              <TableCell>
                                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                                  <div
                                    className="h-2.5 rounded-full"
                                    style={{
                                      width: `${student.progress}%`,
                                      backgroundColor: "var(--primary-color, #eab308)",
                                    }}
                                  ></div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="flex space-x-2">
                                  <Button variant="outline" size="sm" onClick={() => viewStudentDetails(student)}>
                                    View Details
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedStudent(student)
                                      setIsMessageDialogOpen(true)
                                    }}
                                  >
                                    <MessageCircle className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="messages" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Student Messages</CardTitle>
                    <CardDescription>View and respond to messages from your students</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {students.filter((s) => s.messages && s.messages.length > 0).length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p className="mb-4">No messages from students yet.</p>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {students
                          .filter((s) => s.messages && s.messages.length > 0)
                          .map((student) => (
                            <Card key={student.id} className="overflow-hidden">
                              <CardHeader className="bg-gray-100 dark:bg-gray-800 py-3">
                                <div className="flex justify-between items-center">
                                  <CardTitle className="text-lg">{student.name}</CardTitle>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedStudent(student)
                                      setIsMessageDialogOpen(true)
                                    }}
                                  >
                                    Reply
                                  </Button>
                                </div>
                              </CardHeader>
                              <CardContent className="p-0">
                                <div className="max-h-60 overflow-y-auto p-4">
                                  {student.messages.map((msg, index) => (
                                    <div
                                      key={msg.id || index}
                                      className={`p-3 rounded-lg mb-2 ${
                                        msg.from === "therapist"
                                          ? "bg-blue-100 dark:bg-blue-900 ml-8"
                                          : "bg-gray-100 dark:bg-gray-800 mr-8"
                                      } ${msg.from === "student" && !msg.read ? "border-l-4 border-red-500" : ""}`}
                                    >
                                      <div className="flex justify-between items-center mb-1">
                                        <span className="font-medium">
                                          {msg.from === "therapist" ? "You" : student.name}
                                        </span>
                                        <span className="text-xs text-gray-500 dark:text-gray-400">
                                          {new Date(msg.date).toLocaleString()}
                                        </span>
                                      </div>
                                      <p>{msg.text}</p>
                                    </div>
                                  ))}
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="performance" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Overview</CardTitle>
                    <CardDescription>View overall performance metrics for all students</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {students.length === 0 ? (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                        <p className="mb-4">No performance data available yet.</p>
                        <p>Add students and have them play games to generate analytics.</p>
                      </div>
                    ) : (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium">Average Progress</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                {Math.round(
                                  students.reduce((sum, student) => sum + (student.progress || 0), 0) / students.length,
                                )}
                                %
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium">Active Students</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                {students.filter((s) => s.lastActive === "Today").length}/{students.length}
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium">Most Popular Game</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                {(() => {
                                  const games = {
                                    "word-builder": 0,
                                    "memory-matching": 0,
                                    "sound-match": 0,
                                    "rhyme-time": 0,
                                    "word-scramble": 0,
                                    "spell-bee": 0,
                                  }

                                  students.forEach((student) => {
                                    if (student.gamePerformance) {
                                      Object.entries(student.gamePerformance).forEach(([game, data]) => {
                                        games[game] += data.played || 0
                                      })
                                    }
                                  })

                                  const mostPlayed = Object.entries(games).sort((a, b) => b[1] - a[1])[0]

                                  const gameNames = {
                                    "word-builder": "Word Builder",
                                    "memory-matching": "Memory Matching",
                                    "sound-match": "Sound Match",
                                    "rhyme-time": "Rhyme Time",
                                    "word-scramble": "Word Scramble",
                                    "spell-bee": "Spell Bee",
                                  }

                                  return mostPlayed[1] > 0 ? gameNames[mostPlayed[0]] : "None"
                                })()}
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        <div className="mt-8">
                          <h3 className="text-lg font-medium mb-4">Game Performance</h3>
                          <div className="space-y-4">
                            {[
                              "word-builder",
                              "memory-matching",
                              "sound-match",
                              "rhyme-time",
                              "word-scramble",
                              "spell-bee",
                            ].map((gameId) => {
                              const gameNames = {
                                "word-builder": "Word Builder",
                                "memory-matching": "Memory Matching",
                                "sound-match": "Sound Match",
                                "rhyme-time": "Rhyme Time",
                                "word-scramble": "Word Scramble",
                                "spell-bee": "Spell Bee",
                              }

                              let totalScore = 0
                              let totalPlayed = 0

                              students.forEach((student) => {
                                if (student.gamePerformance && student.gamePerformance[gameId]) {
                                  totalScore += student.gamePerformance[gameId].score || 0
                                  totalPlayed += student.gamePerformance[gameId].played || 0
                                }
                              })

                              const percentage =
                                totalPlayed > 0 ? Math.round((totalScore / (totalPlayed * 100)) * 100) : 0

                              return (
                                <div key={gameId} className="space-y-1">
                                  <div className="flex justify-between">
                                    <span>{gameNames[gameId]}</span>
                                    <span className="text-sm text-gray-500 dark:text-gray-400">{percentage}%</span>
                                  </div>
                                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                    <div
                                      className="h-2 rounded-full"
                                      style={{
                                        width: `${percentage}%`,
                                        backgroundColor: "var(--primary-color, #eab308)",
                                      }}
                                    ></div>
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}

