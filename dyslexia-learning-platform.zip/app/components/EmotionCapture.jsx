"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Camera, X, Check, AlertTriangle } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export default function EmotionCapture({ onEmotionData, gameId, studentId, active = true }) {
  const [cameraPermission, setCameraPermission] = useState("pending") // pending, granted, denied
  const [cameraActive, setCameraActive] = useState(false)
  const [captureFrequency, setCaptureFrequency] = useState(30000) // 30 seconds by default
  const [lastEmotion, setLastEmotion] = useState(null)
  const [showPermissionDialog, setShowPermissionDialog] = useState(false)
  const [emotionHistory, setEmotionHistory] = useState([])

  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const streamRef = useRef(null)
  const captureIntervalRef = useRef(null)

  // Initialize camera when component mounts
  useEffect(() => {
    // Check if camera permission is stored
    const storedPermission = localStorage.getItem("cameraPermission")
    if (storedPermission) {
      setCameraPermission(storedPermission)
      if (storedPermission === "granted" && active) {
        initializeCamera()
      } else if (storedPermission === "pending") {
        setShowPermissionDialog(true)
      }
    } else {
      setShowPermissionDialog(true)
    }

    return () => {
      // Clean up camera when component unmounts
      stopCamera()
    }
  }, [active])

  // Initialize camera
  const initializeCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: 320,
          height: 240,
          facingMode: "user",
        },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream
        setCameraActive(true)
        setCameraPermission("granted")
        localStorage.setItem("cameraPermission", "granted")

        // Start capturing emotions
        startEmotionCapture()
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setCameraPermission("denied")
      localStorage.setItem("cameraPermission", "denied")
      toast({
        title: "Camera access denied",
        description: "We can't analyze your emotions without camera access.",
        variant: "destructive",
      })
    }
  }

  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (captureIntervalRef.current) {
      clearInterval(captureIntervalRef.current)
      captureIntervalRef.current = null
    }

    setCameraActive(false)
  }

  // Start emotion capture
  const startEmotionCapture = () => {
    if (captureIntervalRef.current) {
      clearInterval(captureIntervalRef.current)
    }

    // Capture emotions at regular intervals
    captureIntervalRef.current = setInterval(() => {
      captureAndAnalyzeEmotion()
    }, captureFrequency)

    // Capture immediately on start
    captureAndAnalyzeEmotion()
  }

  // Capture and analyze emotion
  const captureAndAnalyzeEmotion = () => {
    if (!videoRef.current || !canvasRef.current || !cameraActive) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    // Draw video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Get image data from canvas
    canvas.toBlob(
      async (blob) => {
        if (!blob) return

        try {
          // In a real app, we would send this to a backend for analysis
          // Here we'll simulate an API call with a mock response
          const emotionData = await mockEmotionAnalysis(blob)

          // Update state with emotion data
          setLastEmotion(emotionData)
          setEmotionHistory((prev) => [...prev, emotionData])

          // Send emotion data to parent component
          if (onEmotionData) {
            onEmotionData(emotionData)
          }

          // Save emotion data to localStorage
          saveEmotionData(emotionData)
        } catch (err) {
          console.error("Error analyzing emotion:", err)
        }
      },
      "image/jpeg",
      0.8,
    )
  }

  // Mock emotion analysis (in a real app, this would be a backend API call)
  const mockEmotionAnalysis = async (imageBlob) => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Generate random emotion data
    const emotions = ["happy", "sad", "neutral", "surprised", "angry", "fearful"]
    const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)]
    const randomIntensity = Math.floor(Math.random() * 100)

    // For demo purposes, weight towards "happy" or "neutral" most of the time
    const weightedEmotion = Math.random() > 0.3 ? (Math.random() > 0.5 ? "happy" : "neutral") : randomEmotion

    return {
      timestamp: new Date().toISOString(),
      emotion: weightedEmotion,
      intensity: randomIntensity,
      gameId,
      studentId,
      confidence: Math.floor(Math.random() * 30) + 70, // 70-100%
    }
  }

  // Save emotion data to localStorage
  const saveEmotionData = (emotionData) => {
    if (!studentId) return

    const key = `emotionData_${studentId}`
    const storedData = JSON.parse(localStorage.getItem(key) || "[]")

    // Add new data and limit history to 100 entries
    const updatedData = [...storedData, emotionData].slice(-100)
    localStorage.setItem(key, JSON.stringify(updatedData))
  }

  // Handle permission dialog response
  const handlePermissionResponse = (granted) => {
    setShowPermissionDialog(false)

    if (granted) {
      initializeCamera()
    } else {
      setCameraPermission("denied")
      localStorage.setItem("cameraPermission", "denied")
    }
  }

  // Get emotion color
  const getEmotionColor = (emotion) => {
    switch (emotion) {
      case "happy":
        return "text-green-500"
      case "sad":
        return "text-blue-500"
      case "angry":
        return "text-red-500"
      case "surprised":
        return "text-purple-500"
      case "fearful":
        return "text-orange-500"
      default:
        return "text-gray-500"
    }
  }

  // Get emotion emoji
  const getEmotionEmoji = (emotion) => {
    switch (emotion) {
      case "happy":
        return "😊"
      case "sad":
        return "😢"
      case "angry":
        return "😠"
      case "surprised":
        return "😲"
      case "fearful":
        return "😨"
      default:
        return "😐"
    }
  }

  return (
    <>
      {/* Hidden video and canvas elements */}
      <div className="hidden">
        <video ref={videoRef} autoPlay playsInline muted width="320" height="240" />
        <canvas ref={canvasRef} width="320" height="240" />
      </div>

      {/* Permission dialog */}
      {showPermissionDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Camera Permission</CardTitle>
              <CardDescription>
                We'd like to use your camera to analyze your emotions while playing games. This helps us understand how
                you feel and adapt the learning experience.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-4">
                Your privacy is important to us. Images are processed locally and not stored permanently. You can
                disable this feature at any time.
              </p>
              <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                <Camera className="h-8 w-8 text-blue-500 mr-3" />
                <div>
                  <h4 className="font-medium">Emotion Analysis</h4>
                  <p className="text-sm text-gray-600">Helps us understand how you feel while learning</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => handlePermissionResponse(false)}>
                <X className="h-4 w-4 mr-2" />
                No Thanks
              </Button>
              <Button onClick={() => handlePermissionResponse(true)}>
                <Check className="h-4 w-4 mr-2" />
                Allow Camera
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      {/* Emotion feedback display */}
      {cameraActive && lastEmotion && (
        <div className="fixed bottom-4 left-4 z-40">
          <Card className="w-64 bg-white bg-opacity-90 backdrop-blur-sm shadow-lg border-2 border-blue-200">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-sm">Emotion Tracker</CardTitle>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={stopCamera}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex items-center mb-2">
                <div className="text-4xl mr-3">{getEmotionEmoji(lastEmotion.emotion)}</div>
                <div>
                  <div className={`font-medium capitalize ${getEmotionColor(lastEmotion.emotion)}`}>
                    {lastEmotion.emotion}
                  </div>
                  <div className="text-xs text-gray-500">Confidence: {lastEmotion.confidence}%</div>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>Intensity</span>
                  <span>{lastEmotion.intensity}%</span>
                </div>
                <Progress value={lastEmotion.intensity} className="h-1" />
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <p className="text-xs text-gray-500 w-full text-center">Analyzing your emotions to enhance learning</p>
            </CardFooter>
          </Card>
        </div>
      )}

      {/* Camera permission denied warning */}
      {cameraPermission === "denied" && active && (
        <div className="fixed bottom-4 left-4 z-40">
          <Card className="w-64 bg-white shadow-lg border-2 border-yellow-200">
            <CardHeader className="pb-2">
              <div className="flex items-center">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                <CardTitle className="text-sm">Emotion Tracking Off</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-gray-500">
                Camera access is required for emotion tracking. Your experience may not be optimized.
              </p>
            </CardContent>
            <CardFooter>
              <Button
                size="sm"
                className="w-full text-xs"
                onClick={() => {
                  localStorage.setItem("cameraPermission", "pending")
                  setCameraPermission("pending")
                  setShowPermissionDialog(true)
                }}
              >
                Enable Camera
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </>
  )
}

