"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Home, Star, Timer, HelpCircle, Volume2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Game levels with increasing difficulty
const GAME_LEVELS = [
  {
    level: 1,
    words: [
      { word: "cat", hint: "A small furry animal that meows" },
      { word: "dog", hint: "A pet that barks" },
      { word: "sun", hint: "It shines in the sky during the day" },
    ],
  },
  {
    level: 2,
    words: [
      { word: "fish", hint: "It swims in water" },
      { word: "bird", hint: "It has wings and can fly" },
      { word: "tree", hint: "It grows in the ground and has leaves" },
    ],
  },
  {
    level: 3,
    words: [
      { word: "house", hint: "A place where people live" },
      { word: "apple", hint: "A red or green fruit" },
      { word: "water", hint: "You drink it when you're thirsty" },
    ],
  },
]

export default function WordScrambleGame() {
  const [currentLevel, setCurrentLevel] = useState(1)
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [scrambledLetters, setScrambledLetters] = useState<string[]>([])
  const [userInput, setUserInput] = useState("")
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(60)
  const [gameActive, setGameActive] = useState(true)
  const [showHint, setShowHint] = useState(false)
  const [hintsUsed, setHintsUsed] = useState(0)

  const levelData = GAME_LEVELS.find((l) => l.level === currentLevel) || GAME_LEVELS[0]
  const currentWord = levelData.words[currentWordIndex].word
  const currentHint = levelData.words[currentWordIndex].hint

  // Initialize game
  useEffect(() => {
    scrambleWord()

    // Timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          setGameActive(false)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [currentLevel, currentWordIndex])

  // Scramble current word
  const scrambleWord = () => {
    const word = levelData.words[currentWordIndex].word
    const letters = word.split("")

    // Shuffle the array
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[letters[i], letters[j]] = [letters[j], letters[i]]
    }

    // Make sure the scrambled word is different from the original
    if (letters.join("") === word) {
      return scrambleWord()
    }

    setScrambledLetters(letters)
    setUserInput("")
    setShowHint(false)
  }

  // Handle user input
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!gameActive) return
    setUserInput(e.target.value)
  }

  // Check answer
  const checkAnswer = () => {
    if (!gameActive) return

    if (userInput.toLowerCase() === currentWord.toLowerCase()) {
      // Correct answer
      const pointsEarned = 10 - hintsUsed * 2
      setScore(score + pointsEarned)

      toast({
        title: "Correct!",
        description: `You earned ${pointsEarned} points!`,
      })

      // Move to next word or level
      if (currentWordIndex < levelData.words.length - 1) {
        setCurrentWordIndex(currentWordIndex + 1)
      } else if (currentLevel < GAME_LEVELS.length) {
        setCurrentLevel(currentLevel + 1)
        setCurrentWordIndex(0)

        toast({
          title: "Level Up!",
          description: `You've advanced to Level ${currentLevel + 1}`,
        })
      } else {
        // Game completed
        setGameActive(false)
        toast({
          title: "Congratulations!",
          description: "You've completed all levels!",
        })
      }
    } else {
      // Incorrect answer
      toast({
        title: "Try again",
        description: "That's not the correct word",
        variant: "destructive",
      })
    }
  }

  // Use hint
  const useHint = () => {
    setShowHint(true)
    setHintsUsed(hintsUsed + 1)
  }

  // Speak the current word
  const speakWord = () => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(currentWord)
      window.speechSynthesis.speak(utterance)
    }
  }

  // Add useEffect to save game data on component unmount
  useEffect(() => {
    return () => {
      // This will run when the component unmounts (user navigates away)
      const username = localStorage.getItem("currentStudent")
      if (username) {
        const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
        const updatedStudents = storedStudents.map((student: any) => {
          if (student.username === username) {
            // Update student's game performance
            const gamePerformance = student.gamePerformance || {}
            const wordScrambleData = gamePerformance["word-scramble"] || { played: 0, score: 0, level: 1 }

            return {
              ...student,
              gamePerformance: {
                ...gamePerformance,
                "word-scramble": {
                  played: wordScrambleData.played + 1,
                  score: wordScrambleData.score + score,
                  level: Math.max(wordScrambleData.level, currentLevel),
                },
              },
              // Update overall progress based on all games
              progress: Math.min(100, student.progress + Math.floor(score / 5)),
            }
          }
          return student
        })

        localStorage.setItem("students", JSON.stringify(updatedStudents))
      }
    }
  }, [score, currentLevel])

  // Update the timer placement and add more animations
  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-orange-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/games">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/games" className="flex items-center space-x-2">
              <Home className="h-5 w-5 text-yellow-500" />
              <span className="font-bold text-xl text-yellow-500">Word Scramble</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="bg-yellow-100 px-3 py-1 rounded-full flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="font-bold">{score}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Timer positioned in the center */}
          <div className="flex justify-center mb-4">
            <div className="bg-red-100 px-6 py-2 rounded-full flex items-center animate-pulse">
              <Timer className="h-5 w-5 text-red-500 mr-2" />
              <span className="font-bold text-xl">{timeLeft}s</span>
            </div>
          </div>

          <Card className="p-6 mb-6 bg-white shadow-lg border-2 border-yellow-300">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Unscramble the Word</h2>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={speakWord}
                  className="rounded-full hover:scale-110 transition-transform"
                >
                  <Volume2 className="h-5 w-5 text-blue-500" />
                </Button>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full hover:scale-110 transition-transform">
                      <HelpCircle className="h-5 w-5 text-purple-500" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>How to Play</DialogTitle>
                      <DialogDescription>
                        Unscramble the letters to form a word. Type your answer in the box and click "Check". Use the
                        hint if you need help.
                      </DialogDescription>
                    </DialogHeader>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span>
                  Word {currentWordIndex + 1} of {levelData.words.length}
                </span>
                <span>Level {currentLevel}</span>
              </div>
              <Progress value={(currentWordIndex / levelData.words.length) * 100} className="h-2" />
            </div>

            {/* Scrambled word display with animation */}
            <div className="bg-yellow-50 p-6 rounded-lg mb-6 flex items-center justify-center">
              <div className="flex space-x-3">
                {scrambledLetters.map((letter, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 flex items-center justify-center rounded-lg bg-yellow-200 border-2 border-yellow-400 text-2xl font-bold transform hover:scale-110 transition-transform animate-bounce"
                    style={{ animationDelay: `${index * 0.1}s`, animationDuration: "1s" }}
                  >
                    {letter}
                  </div>
                ))}
              </div>
            </div>

            {/* Hint with animation */}
            {showHint && (
              <div className="bg-blue-50 p-3 rounded-lg mb-6 text-center animate-fadeIn">
                <p className="text-sm text-blue-800">{currentHint}</p>
              </div>
            )}

            {/* User input */}
            <div className="mb-6">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={userInput}
                  onChange={handleInputChange}
                  placeholder="Type your answer..."
                  className="flex-1 px-4 py-2 border-2 border-yellow-300 rounded-lg text-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                  disabled={!gameActive}
                />
                <Button
                  onClick={checkAnswer}
                  disabled={!gameActive || !userInput}
                  className="bg-yellow-500 hover:bg-yellow-600 hover:scale-105 transition-transform"
                >
                  Check
                </Button>
              </div>
            </div>

            {/* Controls */}
            <div className="flex space-x-2">
              <Button
                variant="outline"
                className="flex-1 hover:bg-yellow-50 transition-colors"
                onClick={scrambleWord}
                disabled={!gameActive}
              >
                Reshuffle
              </Button>
              <Button
                variant="outline"
                className="flex-1 hover:bg-blue-50 transition-colors"
                onClick={useHint}
                disabled={showHint || !gameActive}
              >
                Hint
              </Button>
            </div>
          </Card>

          {!gameActive && (
            <Card className="p-6 bg-yellow-50 border-2 border-yellow-300 text-center animate-fadeIn">
              <h2 className="text-2xl font-bold mb-4">Game Over!</h2>
              <p className="mb-4">Your score: {score}</p>
              <div className="flex space-x-4 justify-center">
                <Link href="/student/games">
                  <Button variant="outline" className="hover:scale-105 transition-transform">
                    Back to Games
                  </Button>
                </Link>
                <Button
                  onClick={() => {
                    setCurrentLevel(1)
                    setCurrentWordIndex(0)
                    setScore(0)
                    setTimeLeft(60)
                    setGameActive(true)
                    setHintsUsed(0)
                  }}
                  className="bg-yellow-500 hover:bg-yellow-600 hover:scale-105 transition-transform"
                >
                  Play Again
                </Button>
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}

