"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Home, Star, Timer, Volume2, HelpCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Game levels with increasing difficulty
const GAME_LEVELS = [
  {
    level: 1,
    questions: [
      {
        word: "cat",
        options: ["hat", "dog", "car", "sun"],
        correctIndex: 0,
      },
      {
        word: "ball",
        options: ["call", "bell", "blue", "bike"],
        correctIndex: 0,
      },
      {
        word: "star",
        options: ["sun", "moon", "car", "tree"],
        correctIndex: 2,
      },
    ],
  },
  {
    level: 2,
    questions: [
      {
        word: "cake",
        options: ["bake", "cook", "eat", "sweet"],
        correctIndex: 0,
      },
      {
        word: "light",
        options: ["dark", "lamp", "night", "day"],
        correctIndex: 2,
      },
      {
        word: "mouse",
        options: ["cat", "cheese", "house", "small"],
        correctIndex: 2,
      },
    ],
  },
  {
    level: 3,
    questions: [
      {
        word: "train",
        options: ["car", "track", "rain", "travel"],
        correctIndex: 2,
      },
      {
        word: "flower",
        options: ["garden", "power", "bloom", "petal"],
        correctIndex: 1,
      },
      {
        word: "bright",
        options: ["light", "dark", "shine", "night"],
        correctIndex: 3,
      },
    ],
  },
]

export default function RhymeTimeGame() {
  const [currentLevel, setCurrentLevel] = useState(1)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(60)
  const [gameActive, setGameActive] = useState(true)

  const levelData = GAME_LEVELS.find((l) => l.level === currentLevel) || GAME_LEVELS[0]
  const currentQuestion = levelData.questions[currentQuestionIndex]

  // Initialize game
  useEffect(() => {
    // Reset selection
    setSelectedOption(null)

    // Timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          setGameActive(false)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [currentLevel, currentQuestionIndex])

  // Speak the word
  const speakWord = (word: string) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(word)
      window.speechSynthesis.speak(utterance)
    }
  }

  // Handle option selection
  const selectOption = (index: number) => {
    if (!gameActive || selectedOption !== null) return

    setSelectedOption(index)

    // Check if correct
    if (index === currentQuestion.correctIndex) {
      // Correct answer
      setScore(score + 10)

      toast({
        title: "Correct!",
        description: "That rhymes!",
      })

      // Move to next question or level after a delay
      setTimeout(() => {
        if (currentQuestionIndex < levelData.questions.length - 1) {
          setCurrentQuestionIndex(currentQuestionIndex + 1)
        } else if (currentLevel < GAME_LEVELS.length) {
          setCurrentLevel(currentLevel + 1)
          setCurrentQuestionIndex(0)

          toast({
            title: "Level Up!",
            description: `You've advanced to Level ${currentLevel + 1}`,
          })
        } else {
          // Game completed
          setGameActive(false)
          toast({
            title: "Congratulations!",
            description: "You've completed all levels!",
          })
        }
      }, 1000)
    } else {
      // Incorrect answer
      toast({
        title: "Try again",
        description: "That doesn't rhyme",
        variant: "destructive",
      })

      // Reset selection after a delay
      setTimeout(() => {
        setSelectedOption(null)
      }, 1000)
    }
  }

  // Add useEffect to save game data on component unmount
  useEffect(() => {
    return () => {
      // This will run when the component unmounts (user navigates away)
      const username = localStorage.getItem("currentStudent")
      if (username) {
        const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
        const updatedStudents = storedStudents.map((student: any) => {
          if (student.username === username) {
            // Update student's game performance
            const gamePerformance = student.gamePerformance || {}
            const rhymeTimeData = gamePerformance["rhyme-time"] || { played: 0, score: 0, level: 1 }

            return {
              ...student,
              gamePerformance: {
                ...gamePerformance,
                "rhyme-time": {
                  played: rhymeTimeData.played + 1,
                  score: rhymeTimeData.score + score,
                  level: Math.max(rhymeTimeData.level, currentLevel),
                },
              },
              // Update overall progress based on all games
              progress: Math.min(100, student.progress + Math.floor(score / 5)),
            }
          }
          return student
        })

        localStorage.setItem("students", JSON.stringify(updatedStudents))
      }
    }
  }, [score, currentLevel])

  // Update the timer placement and add more animations
  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-pink-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/games">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/games" className="flex items-center space-x-2">
              <Home className="h-5 w-5 text-red-500" />
              <span className="font-bold text-xl text-red-500">Rhyme Time</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="bg-yellow-100 px-3 py-1 rounded-full flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="font-bold">{score}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Timer positioned in the center */}
          <div className="flex justify-center mb-4">
            <div className="bg-red-100 px-6 py-2 rounded-full flex items-center animate-pulse">
              <Timer className="h-5 w-5 text-red-500 mr-2" />
              <span className="font-bold text-xl">{timeLeft}s</span>
            </div>
          </div>

          <Card className="p-6 mb-6 bg-white shadow-lg border-2 border-red-300">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Find the Rhyming Word</h2>
              <div className="flex space-x-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full hover:scale-110 transition-transform">
                      <HelpCircle className="h-5 w-5 text-purple-500" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>How to Play</DialogTitle>
                      <DialogDescription>
                        Find the word that rhymes with the given word. Rhyming words have the same ending sound.
                      </DialogDescription>
                    </DialogHeader>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span>
                  Question {currentQuestionIndex + 1} of {levelData.questions.length}
                </span>
                <span>Level {currentLevel}</span>
              </div>
              <Progress value={(currentQuestionIndex / levelData.questions.length) * 100} className="h-2" />
            </div>

            {/* Word display with animation */}
            <div className="bg-red-50 p-6 rounded-lg mb-6 text-center">
              <div className="mb-2 text-sm text-gray-500">Which word rhymes with:</div>
              <div className="flex items-center justify-center space-x-2">
                <div className="text-3xl font-bold text-red-700 animate-bounce">{currentQuestion.word}</div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => speakWord(currentQuestion.word)}
                  className="rounded-full hover:scale-110 transition-transform"
                >
                  <Volume2 className="h-5 w-5 text-red-500" />
                </Button>
              </div>
            </div>

            {/* Options with enhanced animations */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              {currentQuestion.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className={`h-16 text-lg transition-all duration-300 hover:scale-105 transform
                  ${
                    selectedOption === index
                      ? index === currentQuestion.correctIndex
                        ? "bg-green-100 border-green-500 animate-bounce"
                        : "bg-red-100 border-red-500 animate-shake"
                      : "bg-white hover:bg-red-50"
                  }`}
                  onClick={() => selectOption(index)}
                  disabled={selectedOption !== null}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <span>{option}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation()
                        speakWord(option)
                      }}
                      className="h-6 w-6 rounded-full hover:scale-110 transition-transform"
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {!gameActive && (
            <Card className="p-6 bg-red-50 border-2 border-red-300 text-center animate-fadeIn">
              <h2 className="text-2xl font-bold mb-4">Game Over!</h2>
              <p className="mb-4">Your score: {score}</p>
              <div className="flex space-x-4 justify-center">
                <Link href="/student/games">
                  <Button variant="outline" className="hover:scale-105 transition-transform">
                    Back to Games
                  </Button>
                </Link>
                <Button
                  onClick={() => {
                    setCurrentLevel(1)
                    setCurrentQuestionIndex(0)
                    setScore(0)
                    setTimeLeft(60)
                    setGameActive(true)
                  }}
                  className="bg-red-500 hover:bg-red-600 hover:scale-105 transition-transform"
                >
                  Play Again
                </Button>
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}

