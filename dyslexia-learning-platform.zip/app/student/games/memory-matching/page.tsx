"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Home, Star, Timer, Trophy } from "lucide-react"

// Card types with increasing difficulty per level
const GAME_LEVELS = [
  {
    level: 1,
    gridSize: [2, 3], // 2x3 grid (6 cards, 3 pairs)
    cards: ["🐶", "🐱", "🐰"],
  },
  {
    level: 2,
    gridSize: [3, 4], // 3x4 grid (12 cards, 6 pairs)
    cards: ["🐶", "🐱", "🐰", "🐻", "🐼", "🦊"],
  },
  {
    level: 3,
    gridSize: [4, 4], // 4x4 grid (16 cards, 8 pairs)
    cards: ["🐶", "🐱", "🐰", "🐻", "🐼", "🦊", "🦁", "🐯"],
  },
]

export default function MemoryMatchingGame() {
  const [currentLevel, setCurrentLevel] = useState(1)
  const [cards, setCards] = useState<{ id: number; value: string; flipped: boolean; matched: boolean }[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matchedPairs, setMatchedPairs] = useState(0)
  const [moves, setMoves] = useState(0)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(60)
  const [gameActive, setGameActive] = useState(true)
  const [gameStarted, setGameStarted] = useState(false)

  const levelData = GAME_LEVELS.find((l) => l.level === currentLevel) || GAME_LEVELS[0]
  const totalPairs = levelData.cards.length

  // Initialize game
  useEffect(() => {
    initializeCards()
  }, [currentLevel])

  // Timer
  useEffect(() => {
    if (!gameStarted || !gameActive) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          setGameActive(false)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameActive])

  // Check for level completion
  useEffect(() => {
    if (matchedPairs === totalPairs && gameActive) {
      // Level completed
      const timeBonus = Math.floor(timeLeft / 2)
      const movePenalty = Math.floor(moves / 2)
      const levelPoints = 50 + timeBonus - movePenalty

      setScore((prev) => prev + levelPoints)

      toast({
        title: "Level Complete!",
        description: `You earned ${levelPoints} points!`,
      })

      // Move to next level or end game
      if (currentLevel < GAME_LEVELS.length) {
        setTimeout(() => {
          setCurrentLevel(currentLevel + 1)
          setMatchedPairs(0)
          setMoves(0)
          setFlippedCards([])
          setTimeLeft(60)
        }, 1500)
      } else {
        // Game completed
        setGameActive(false)
        toast({
          title: "Congratulations!",
          description: "You've completed all levels!",
        })
      }
    }
  }, [matchedPairs, totalPairs, gameActive, currentLevel, timeLeft, moves])

  // Initialize cards for current level
  const initializeCards = () => {
    const levelData = GAME_LEVELS.find((l) => l.level === currentLevel) || GAME_LEVELS[0]
    const cardValues = [...levelData.cards, ...levelData.cards] // Create pairs

    // Shuffle the cards
    for (let i = cardValues.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[cardValues[i], cardValues[j]] = [cardValues[j], cardValues[i]]
    }

    // Create card objects
    const newCards = cardValues.map((value, index) => ({
      id: index,
      value,
      flipped: false,
      matched: false,
    }))

    setCards(newCards)
    setMatchedPairs(0)
    setMoves(0)
    setFlippedCards([])
  }

  // Handle card click
  const handleCardClick = (id: number) => {
    if (!gameActive) return
    if (!gameStarted) setGameStarted(true)

    // Ignore if card is already flipped or matched
    if (cards[id].flipped || cards[id].matched) return

    // Ignore if two cards are already flipped
    if (flippedCards.length === 2) return

    // Flip the card
    const newCards = [...cards]
    newCards[id].flipped = true
    setCards(newCards)

    // Add to flipped cards
    const newFlippedCards = [...flippedCards, id]
    setFlippedCards(newFlippedCards)

    // If two cards are flipped, check for match
    if (newFlippedCards.length === 2) {
      setMoves(moves + 1)

      const [firstId, secondId] = newFlippedCards

      if (cards[firstId].value === cards[secondId].value) {
        // Match found
        setTimeout(() => {
          const matchedCards = [...cards]
          matchedCards[firstId].matched = true
          matchedCards[secondId].matched = true
          setCards(matchedCards)
          setMatchedPairs(matchedPairs + 1)
          setFlippedCards([])
        }, 500)
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...cards]
          resetCards[firstId].flipped = false
          resetCards[secondId].flipped = false
          setCards(resetCards)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  // Reset game
  const resetGame = () => {
    setCurrentLevel(1)
    setScore(0)
    setTimeLeft(60)
    setGameActive(true)
    setGameStarted(false)
    setMatchedPairs(0)
    setMoves(0)
    setFlippedCards([])
    initializeCards()
  }

  // Calculate grid template based on level
  const gridTemplate = () => {
    const [rows, cols] = levelData.gridSize
    return {
      gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
      gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
    }
  }

  // Add useEffect to save game data on component unmount
  useEffect(() => {
    return () => {
      // This will run when the component unmounts (user navigates away)
      const username = localStorage.getItem("currentStudent")
      if (username) {
        const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
        const updatedStudents = storedStudents.map((student: any) => {
          if (student.username === username) {
            // Update student's game performance
            const gamePerformance = student.gamePerformance || {}
            const memoryMatchData = gamePerformance["memory-matching"] || { played: 0, score: 0, level: 1 }

            return {
              ...student,
              gamePerformance: {
                ...gamePerformance,
                "memory-matching": {
                  played: memoryMatchData.played + 1,
                  score: memoryMatchData.score + score,
                  level: Math.max(memoryMatchData.level, currentLevel),
                },
              },
              // Update overall progress based on all games
              progress: Math.min(100, student.progress + Math.floor(score / 5)),
            }
          }
          return student
        })

        localStorage.setItem("students", JSON.stringify(updatedStudents))
      }
    }
  }, [score, currentLevel])

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/games">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/games" className="flex items-center space-x-2">
              <Home className="h-5 w-5 text-purple-500" />
              <span className="font-bold text-xl text-purple-500">Memory Match</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="bg-yellow-100 px-3 py-1 rounded-full flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="font-bold">{score}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Timer positioned in the center */}
          <div className="flex justify-center mb-4">
            <div className="bg-red-100 px-6 py-2 rounded-full flex items-center animate-pulse">
              <Timer className="h-5 w-5 text-red-500 mr-2" />
              <span className="font-bold text-xl">{timeLeft}s</span>
            </div>
          </div>

          <Card className="p-6 mb-6 bg-white shadow-lg border-2 border-purple-300">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Match the Pairs</h2>
              <div className="flex space-x-4">
                <div className="text-sm">Moves: {moves}</div>
                <div className="text-sm">
                  Pairs: {matchedPairs}/{totalPairs}
                </div>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Level {currentLevel}</span>
                <span>
                  {matchedPairs}/{totalPairs} Pairs
                </span>
              </div>
              <Progress value={(matchedPairs / totalPairs) * 100} className="h-2" />
            </div>

            {/* Game board with enhanced animations */}
            <div className="grid gap-2 mb-4" style={gridTemplate()}>
              {cards.map((card) => (
                <div
                  key={card.id}
                  className={`aspect-square rounded-lg cursor-pointer transition-all duration-500 transform hover:scale-105
                  ${card.flipped || card.matched ? "rotate-y-180" : ""}`}
                  onClick={() => handleCardClick(card.id)}
                >
                  <div
                    className={`w-full h-full flex items-center justify-center text-3xl rounded-lg shadow-md
                    ${card.matched ? "bg-purple-200 border-2 border-purple-400 animate-pulse" : ""}
                    ${card.flipped && !card.matched ? "bg-purple-200 border-2 border-purple-400" : "bg-purple-500"}
                    transition-all duration-300`}
                  >
                    {card.flipped || card.matched ? <span className="animate-fadeIn">{card.value}</span> : ""}
                  </div>
                </div>
              ))}
            </div>

            {!gameStarted && (
              <div className="text-center">
                <Button
                  onClick={() => setGameStarted(true)}
                  className="bg-purple-500 hover:bg-purple-600 hover:scale-110 transition-transform animate-bounce"
                >
                  Start Game
                </Button>
              </div>
            )}
          </Card>

          {!gameActive && (
            <Card className="p-6 bg-purple-50 border-2 border-purple-300 text-center animate-fadeIn">
              <h2 className="text-2xl font-bold mb-4">Game Over!</h2>
              <div className="flex justify-center items-center mb-4">
                <Trophy className="h-12 w-12 text-yellow-500 mr-2 animate-bounce" />
                <span className="text-3xl font-bold">{score}</span>
              </div>
              <p className="mb-6">You reached Level {currentLevel}</p>
              <div className="flex space-x-4 justify-center">
                <Link href="/student/games">
                  <Button variant="outline" className="hover:scale-105 transition-transform">
                    Back to Games
                  </Button>
                </Link>
                <Button
                  onClick={resetGame}
                  className="bg-purple-500 hover:bg-purple-600 hover:scale-105 transition-transform"
                >
                  Play Again
                </Button>
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}

