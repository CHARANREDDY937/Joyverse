"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Home, Volume2, Star, HelpCircle, Sparkles } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Game levels with increasing difficulty
const GAME_LEVELS = [
  {
    level: 1,
    words: [
      { word: "cat", hint: "A small furry animal that meows" },
      { word: "dog", hint: "A pet that barks" },
      { word: "sun", hint: "It shines in the sky during the day" },
    ],
  },
  {
    level: 2,
    words: [
      { word: "fish", hint: "It swims in water" },
      { word: "bird", hint: "It has wings and can fly" },
      { word: "tree", hint: "It grows in the ground and has leaves" },
    ],
  },
  {
    level: 3,
    words: [
      { word: "house", hint: "A place where people live" },
      { word: "apple", hint: "A red or green fruit" },
      { word: "water", hint: "You drink it when you're thirsty" },
    ],
  },
]

export default function WordBuilderGame() {
  const [currentLevel, setCurrentLevel] = useState(1)
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [availableLetters, setAvailableLetters] = useState<string[]>([])
  const [selectedLetters, setSelectedLetters] = useState<string[]>([])
  const [score, setScore] = useState(0)
  const [gameActive, setGameActive] = useState(true)
  const [showHint, setShowHint] = useState(false)
  const [hintsUsed, setHintsUsed] = useState(0)
  const [theme, setTheme] = useState("default") // default, space, ocean, jungle
  const [showThemeSelector, setShowThemeSelector] = useState(false)
  const [showCelebration, setShowCelebration] = useState(false)
  const [studentId, setStudentId] = useState(null)

  const levelData = GAME_LEVELS.find((l) => l.level === currentLevel) || GAME_LEVELS[0]
  const currentWord = levelData.words[currentWordIndex].word
  const currentHint = levelData.words[currentWordIndex].hint

  // Initialize game
  useEffect(() => {
    // Get current student ID for proper data isolation
    const username = localStorage.getItem("currentStudent")
    if (username) {
      const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
      const student = storedStudents.find((s) => s.username === username)
      if (student) {
        setStudentId(student.id)
      }
    }

    resetWord()
  }, [currentLevel, currentWordIndex])

  // Reset current word
  const resetWord = () => {
    const word = levelData.words[currentWordIndex].word

    // Create shuffled letters
    const letters = word.split("")
    const shuffled = [...letters]

    // Add some extra random letters to make it more challenging
    const extraLetters = "abcdefghijklmnopqrstuvwxyz"
    for (let i = 0; i < Math.min(3, Math.floor(word.length / 2)); i++) {
      const randomLetter = extraLetters[Math.floor(Math.random() * extraLetters.length)]
      shuffled.push(randomLetter)
    }

    // Shuffle the array
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
    }

    setAvailableLetters(shuffled)
    setSelectedLetters([])
    setShowHint(false)
  }

  // Handle letter selection
  const selectLetter = (letter: string, index: number) => {
    if (!gameActive) return

    const newAvailable = [...availableLetters]
    newAvailable.splice(index, 1)

    setAvailableLetters(newAvailable)
    setSelectedLetters([...selectedLetters, letter])

    // Check if word is complete
    if ([...selectedLetters, letter].join("") === currentWord) {
      // Word completed successfully
      const pointsEarned = 10 - hintsUsed * 2
      setScore(score + pointsEarned)

      // Show celebration animation
      setShowCelebration(true)
      setTimeout(() => setShowCelebration(false), 2000)

      toast({
        title: "Great job!",
        description: `You earned ${pointsEarned} points!`,
      })

      // Move to next word or level
      if (currentWordIndex < levelData.words.length - 1) {
        setCurrentWordIndex(currentWordIndex + 1)
      } else if (currentLevel < GAME_LEVELS.length) {
        setCurrentLevel(currentLevel + 1)
        setCurrentWordIndex(0)

        toast({
          title: "Level Up!",
          description: `You've advanced to Level ${currentLevel + 1}`,
        })
      } else {
        // Game completed
        setGameActive(false)
        toast({
          title: "Congratulations!",
          description: "You've completed all levels!",
        })
        saveGameData()
      }
    }
  }

  // Remove the last selected letter
  const removeLastLetter = () => {
    if (selectedLetters.length === 0 || !gameActive) return

    const letter = selectedLetters[selectedLetters.length - 1]
    const newSelected = [...selectedLetters]
    newSelected.pop()

    setSelectedLetters(newSelected)
    setAvailableLetters([...availableLetters, letter])
  }

  // Reset current word
  const resetCurrentWord = () => {
    resetWord()
  }

  // Use hint
  const useHint = () => {
    setShowHint(true)
    setHintsUsed(hintsUsed + 1)
  }

  // Speak the current word
  const speakWord = () => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(currentWord)
      window.speechSynthesis.speak(utterance)
    }
  }

  // Save game data
  const saveGameData = () => {
    if (!studentId) return

    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const updatedStudents = storedStudents.map((student) => {
      if (student.id === studentId) {
        // Update student's game performance
        const gamePerformance = student.gamePerformance || {}
        const wordBuilderData = gamePerformance["word-builder"] || { played: 0, score: 0, level: 1 }

        return {
          ...student,
          gamePerformance: {
            ...gamePerformance,
            "word-builder": {
              played: wordBuilderData.played + 1,
              score: wordBuilderData.score + score,
              level: Math.max(wordBuilderData.level, currentLevel),
            },
          },
          // Update overall progress based on all games
          progress: Math.min(100, student.progress + Math.floor(score / 5)),
        }
      }
      return student
    })

    localStorage.setItem("students", JSON.stringify(updatedStudents))
  }

  // Save game data on component unmount
  useEffect(() => {
    return () => {
      saveGameData()
    }
  }, [score, currentLevel])

  // Get theme-specific classes
  const getThemeClasses = () => {
    switch (theme) {
      case "space":
        return {
          background: "bg-gradient-to-b from-indigo-900 to-purple-900",
          card: "bg-indigo-800 border-purple-500 text-white",
          button: "bg-purple-600 hover:bg-purple-700",
          letterBox: "bg-indigo-700 border-purple-400",
          accent: "text-purple-300",
        }
      case "ocean":
        return {
          background: "bg-gradient-to-b from-blue-400 to-cyan-600",
          card: "bg-blue-50 border-blue-400",
          button: "bg-cyan-500 hover:bg-cyan-600",
          letterBox: "bg-blue-100 border-blue-300",
          accent: "text-cyan-600",
        }
      case "jungle":
        return {
          background: "bg-gradient-to-b from-green-500 to-lime-600",
          card: "bg-green-50 border-green-400",
          button: "bg-lime-600 hover:bg-lime-700",
          letterBox: "bg-green-100 border-green-300",
          accent: "text-lime-700",
        }
      default:
        return {
          background: "bg-gradient-to-b from-green-50 to-blue-50",
          card: "bg-white border-green-300",
          button: "bg-green-500 hover:bg-green-600",
          letterBox: "bg-green-100 border-green-300",
          accent: "text-green-500",
        }
    }
  }

  const themeClasses = getThemeClasses()

  return (
    <div className={`min-h-screen ${themeClasses.background} transition-colors duration-500`}>
      {showCelebration && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-50">
          <div className="animate-bounce text-6xl">🎉</div>
          <div className="absolute top-1/4 left-1/4 animate-ping text-5xl delay-100">✨</div>
          <div className="absolute bottom-1/3 right-1/3 animate-ping text-5xl delay-300">🌟</div>
          <div className="absolute top-1/3 right-1/4 animate-ping text-5xl delay-500">⭐</div>
          <div className="absolute bottom-1/4 left-1/3 animate-ping text-5xl delay-700">🎊</div>
        </div>
      )}

      <header
        className={`${theme === "default" ? "bg-white" : themeClasses.card} shadow-md transition-colors duration-500`}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/dashboard">
              <Button variant="ghost" size="icon" className={theme !== "default" ? "text-white" : ""}>
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/dashboard" className="flex items-center space-x-2">
              <Home className={`h-5 w-5 ${themeClasses.accent}`} />
              <span className={`font-bold text-xl ${themeClasses.accent}`}>Word Builder</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="bg-yellow-100 px-3 py-1 rounded-full flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="font-bold">{score}</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowThemeSelector(!showThemeSelector)}
              className="flex items-center"
            >
              <Sparkles className="h-4 w-4 mr-1" />
              Theme
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {showThemeSelector && (
          <div className="max-w-2xl mx-auto mb-6 grid grid-cols-4 gap-4">
            <Button
              className={`h-16 ${theme === "default" ? "ring-4 ring-green-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("default")}
            >
              <div className="w-full h-full bg-gradient-to-b from-green-50 to-blue-50 rounded-md"></div>
            </Button>
            <Button
              className={`h-16 ${theme === "space" ? "ring-4 ring-purple-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("space")}
            >
              <div className="w-full h-full bg-gradient-to-b from-indigo-900 to-purple-900 rounded-md"></div>
            </Button>
            <Button
              className={`h-16 ${theme === "ocean" ? "ring-4 ring-blue-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("ocean")}
            >
              <div className="w-full h-full bg-gradient-to-b from-blue-400 to-cyan-600 rounded-md"></div>
            </Button>
            <Button
              className={`h-16 ${theme === "jungle" ? "ring-4 ring-green-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("jungle")}
            >
              <div className="w-full h-full bg-gradient-to-b from-green-500 to-lime-600 rounded-md"></div>
            </Button>
          </div>
        )}

        <div className="max-w-2xl mx-auto">
          <Card className={`p-6 mb-6 shadow-lg border-2 ${themeClasses.card} transition-colors duration-500`}>
            <div className="flex justify-between items-center mb-4">
              <h2 className={`text-xl font-bold ${theme !== "default" && theme === "space" ? "text-white" : ""}`}>
                Build the Word
              </h2>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={speakWord}
                  className="rounded-full hover:scale-110 transition-transform"
                >
                  <Volume2 className="h-5 w-5 text-blue-500" />
                </Button>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full hover:scale-110 transition-transform">
                      <HelpCircle className="h-5 w-5 text-purple-500" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>How to Play</DialogTitle>
                      <DialogDescription>
                        Select letters to build the word. Use the hint if you need help. You can remove letters by
                        clicking the "Backspace" button.
                      </DialogDescription>
                    </DialogHeader>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span className={theme === "space" ? "text-white" : ""}>
                  Word {currentWordIndex + 1} of {levelData.words.length}
                </span>
                <span className={theme === "space" ? "text-white" : ""}>Level {currentLevel}</span>
              </div>
              <Progress value={(currentWordIndex / levelData.words.length) * 100} className="h-2" />
            </div>

            {/* Word display area with animation */}
            <div
              className={`${theme === "space" ? "bg-indigo-700" : "bg-green-50"} p-4 rounded-lg mb-6 min-h-20 flex items-center justify-center transition-colors duration-500`}
            >
              <div className="flex space-x-2">
                {currentWord.split("").map((letter, index) => (
                  <div
                    key={index}
                    className={`w-12 h-12 flex items-center justify-center rounded-lg border-2 transition-all duration-300
                    ${
                      index < selectedLetters.length
                        ? `${theme === "space" ? "bg-purple-600 border-purple-400" : "bg-green-200 border-green-400"} animate-bounce`
                        : `${theme === "space" ? "bg-indigo-800 border-indigo-600" : "bg-white border-gray-300"}`
                    }`}
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    {index < selectedLetters.length ? (
                      <span className={`text-xl font-bold ${theme === "space" ? "text-white" : ""}`}>
                        {selectedLetters[index]}
                      </span>
                    ) : null}
                  </div>
                ))}
              </div>
            </div>

            {/* Hint with animation */}
            {showHint && (
              <div
                className={`${theme === "space" ? "bg-indigo-700 text-white" : "bg-yellow-50 text-yellow-800"} p-3 rounded-lg mb-6 text-center animate-fadeIn transition-colors duration-500`}
              >
                <p className="text-sm">{currentHint}</p>
              </div>
            )}

            {/* Available letters with animation */}
            <div className="grid grid-cols-5 gap-2 mb-6">
              {availableLetters.map((letter, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className={`h-12 text-lg font-bold ${themeClasses.letterBox} hover:scale-110 transition-transform ${theme === "space" ? "text-white" : ""}`}
                  onClick={() => selectLetter(letter, index)}
                  disabled={!gameActive}
                >
                  {letter}
                </Button>
              ))}
            </div>

            {/* Controls */}
            <div className="flex space-x-2">
              <Button
                variant="outline"
                className={`flex-1 hover:bg-red-50 transition-colors ${theme === "space" ? "text-white hover:bg-indigo-700" : ""}`}
                onClick={removeLastLetter}
                disabled={selectedLetters.length === 0 || !gameActive}
              >
                Backspace
              </Button>
              <Button
                variant="outline"
                className={`flex-1 hover:bg-blue-50 transition-colors ${theme === "space" ? "text-white hover:bg-indigo-700" : ""}`}
                onClick={resetCurrentWord}
                disabled={!gameActive}
              >
                Reset
              </Button>
              <Button
                variant="outline"
                className={`flex-1 hover:bg-yellow-50 transition-colors ${theme === "space" ? "text-white hover:bg-indigo-700" : ""}`}
                onClick={useHint}
                disabled={showHint || !gameActive}
              >
                Hint
              </Button>
            </div>
          </Card>

          {!gameActive && (
            <Card
              className={`p-6 text-center animate-fadeIn ${themeClasses.card} border-2 transition-colors duration-500`}
            >
              <div className="py-4">
                <div className="flex justify-center mb-4">
                  <div className="text-6xl animate-bounce">🏆</div>
                </div>
                <h2 className={`text-2xl font-bold mb-4 ${theme === "space" ? "text-white" : ""}`}>Game Over!</h2>
                <p className={`mb-4 text-xl ${theme === "space" ? "text-white" : ""}`}>Your score: {score}</p>

                <div className="flex flex-wrap justify-center gap-4 mb-6">
                  <div className="animate-bounce delay-100">🎉</div>
                  <div className="animate-bounce delay-200">🎊</div>
                  <div className="animate-bounce delay-300">🌟</div>
                  <div className="animate-bounce delay-400">✨</div>
                  <div className="animate-bounce delay-500">🏅</div>
                </div>

                <div className="flex space-x-4 justify-center">
                  <Link href="/student/dashboard">
                    <Button variant="outline" className="hover:scale-105 transition-transform">
                      Back to Dashboard
                    </Button>
                  </Link>
                  <Button
                    onClick={() => {
                      setCurrentLevel(1)
                      setCurrentWordIndex(0)
                      setScore(0)
                      setGameActive(true)
                      setHintsUsed(0)
                      resetWord()
                    }}
                    className={`${themeClasses.button} hover:scale-105 transition-transform`}
                  >
                    Play Again
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}

