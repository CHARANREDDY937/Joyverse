"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BookOpen, Brain, Music, Puzzle, Shuffle, Trophy, Home, Volume2, LogOut } from "lucide-react"
import { useRouter } from "next/navigation"

export default function GamesPage() {
  const [studentName, setStudentName] = useState("Alex")
  const [level, setLevel] = useState(2)
  const [xp, setXp] = useState(350)
  const [nextLevelXp, setNextLevelXp] = useState(500)
  const router = useRouter()

  useEffect(() => {
    const username = localStorage.getItem("currentStudent")
    if (username) {
      const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
      const student = storedStudents.find((s: any) => s.username === username)

      if (student) {
        setStudentName(student.name)
        setLevel(student.level || 1)
        setXp(student.progress * 5 || 0)
        setNextLevelXp(500)
      }
    }
  }, [])

  const games = [
    {
      id: "word-builder",
      title: "Word Builder",
      description: "Build words from letters",
      icon: <BookOpen className="h-8 w-8 text-green-500" />,
      color: "bg-green-100 border-green-300",
      iconBg: "bg-green-200",
      progress: 75,
      path: "/student/games/word-builder",
    },
    {
      id: "memory-matching",
      title: "Memory Matching",
      description: "Match pairs of cards",
      icon: <Brain className="h-8 w-8 text-purple-500" />,
      color: "bg-purple-100 border-purple-300",
      iconBg: "bg-purple-200",
      progress: 60,
      path: "/student/games/memory-matching",
    },
    {
      id: "sound-match",
      title: "Sound Match",
      description: "Match sounds with words",
      icon: <Music className="h-8 w-8 text-blue-500" />,
      color: "bg-blue-100 border-blue-300",
      iconBg: "bg-blue-200",
      progress: 40,
      path: "/student/games/sound-match",
    },
    {
      id: "rhyme-time",
      title: "Rhyme Time",
      description: "Find words that rhyme",
      icon: <Puzzle className="h-8 w-8 text-red-500" />,
      color: "bg-red-100 border-red-300",
      iconBg: "bg-red-200",
      progress: 30,
      path: "/student/games/rhyme-time",
    },
    {
      id: "word-scramble",
      title: "Word Scramble",
      description: "Unscramble the letters",
      icon: <Shuffle className="h-8 w-8 text-yellow-500" />,
      color: "bg-yellow-100 border-yellow-300",
      iconBg: "bg-yellow-200",
      progress: 50,
      path: "/student/games/word-scramble",
    },
    {
      id: "spell-bee",
      title: "Spell Bee",
      description: "Spell words correctly",
      icon: <Volume2 className="h-8 w-8 text-orange-500" />,
      color: "bg-orange-100 border-orange-300",
      iconBg: "bg-orange-200",
      progress: 20,
      path: "/student/games/spell-bee",
    },
  ]

  const handleLogout = () => {
    // Save any final game data
    localStorage.removeItem("currentStudent")
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-500" />
            <span className="font-bold text-xl text-blue-500">PlayLearn</span>
          </Link>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="font-bold text-gray-800">{studentName}</div>
              <div className="text-sm text-gray-500">Level {level}</div>
            </div>
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Student avatar"
                width={40}
                height={40}
                className="rounded-full"
              />
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Welcome back, {studentName}!</h2>
              <p className="text-gray-600">Ready to play and learn today?</p>
            </div>
            <div className="flex items-center space-x-2">
              <Trophy className="h-6 w-6 text-yellow-500" />
              <span className="font-bold text-yellow-500">{xp} XP</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Level {level}</span>
              <span>
                {xp}/{nextLevelXp} XP to Level {level + 1}
              </span>
            </div>
            <Progress value={(xp / nextLevelXp) * 100} className="h-3" />
          </div>
        </div>

        <h2 className="text-2xl font-bold text-gray-800 mb-6">Choose a Game</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game) => (
            <Link href={game.path} key={game.id}>
              <Card className={`border-2 hover:shadow-lg transition-all hover:scale-105 ${game.color}`}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className={`p-3 rounded-lg ${game.iconBg}`}>{game.icon}</div>
                    <div className="text-sm font-medium text-gray-500">Level {level}</div>
                  </div>
                  <CardTitle className="mt-4 text-xl">{game.title}</CardTitle>
                  <CardDescription>{game.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{game.progress}%</span>
                    </div>
                    <Progress value={game.progress} className="h-2" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Play Now</Button>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}

