"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Home, Star, HelpCircle, Volume2, Sparkles, Clock, Zap, Lightbulb } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Add this import at the top of the file
import EmotionCapture from "@/components/EmotionCapture"

// Word database with categories and difficulty levels
const WORD_DATABASE = {
  round1: [
    {
      word: "cat",
      hint: "A small furry animal that meows",
      definition: "A small domesticated carnivorous mammal with soft fur.",
    },
    {
      word: "dog",
      hint: "A pet that barks",
      definition: "A domesticated carnivorous mammal that typically has a long snout.",
    },
    { word: "sun", hint: "It shines in the sky during the day", definition: "The star around which the earth orbits." },
    { word: "hat", hint: "You wear it on your head", definition: "A shaped covering for the head." },
    { word: "pen", hint: "You write with it", definition: "An instrument for writing or drawing with ink." },
    { word: "cup", hint: "You drink from it", definition: "A small, open container for liquids." },
    { word: "bed", hint: "You sleep on it", definition: "A piece of furniture for sleep or rest." },
    {
      word: "bus",
      hint: "A large vehicle that carries many people",
      definition: "A large motor vehicle carrying passengers by road.",
    },
    {
      word: "fox",
      hint: "A wild animal with a bushy tail",
      definition: "A carnivorous mammal with a pointed face and bushy tail.",
    },
    {
      word: "pig",
      hint: "A farm animal that says oink",
      definition: "A domesticated mammal with a snout for digging.",
    },
  ],
  round2: [
    { word: "fish", hint: "It swims in water", definition: "A cold-blooded animal that lives in water." },
    { word: "bird", hint: "It has wings and can fly", definition: "A warm-blooded egg-laying animal with wings." },
    {
      word: "tree",
      hint: "It grows in the ground and has leaves",
      definition: "A woody perennial plant with a single main stem.",
    },
    {
      word: "cake",
      hint: "A sweet dessert for birthdays",
      definition: "A sweet baked food made from flour, sugar, and other ingredients.",
    },
    { word: "book", hint: "You read it", definition: "A written or printed work consisting of pages." },
    {
      word: "frog",
      hint: "A green animal that jumps",
      definition: "A tailless amphibian with a short body and long hind legs.",
    },
    {
      word: "kite",
      hint: "It flies in the sky on a string",
      definition: "A toy consisting of a light frame with thin material stretched over it.",
    },
    { word: "milk", hint: "A white drink from cows", definition: "A white liquid produced by female mammals." },
    { word: "star", hint: "A bright point in the night sky", definition: "A luminous ball of gas in space." },
    {
      word: "door",
      hint: "You walk through it to enter a room",
      definition: "A hinged barrier used to close off an entrance.",
    },
  ],
  round3: [
    { word: "house", hint: "A place where people live", definition: "A building for human habitation." },
    { word: "apple", hint: "A red or green fruit", definition: "The round fruit of a tree of the rose family." },
    {
      word: "water",
      hint: "You drink it when you're thirsty",
      definition: "A colorless, transparent liquid that forms oceans, lakes, rivers, and rain.",
    },
    {
      word: "tiger",
      hint: "A big cat with stripes",
      definition: "A large wild cat with orange fur and black stripes.",
    },
    { word: "snake", hint: "A reptile with no legs", definition: "A long limbless reptile that has no eyelids." },
    {
      word: "plane",
      hint: "It flies in the sky with people",
      definition: "A powered flying vehicle with fixed wings.",
    },
    {
      word: "beach",
      hint: "A sandy shore by the ocean",
      definition: "A pebbly or sandy shore, especially by the sea.",
    },
    {
      word: "cloud",
      hint: "White fluffy thing in the sky",
      definition: "A visible mass of water droplets in the atmosphere.",
    },
    { word: "mouse", hint: "A small rodent", definition: "A small rodent with a pointed snout and long tail." },
    {
      word: "bread",
      hint: "Food made from flour",
      definition: "Food made of flour, water, and yeast mixed together and baked.",
    },
  ],
}

export default function SpellBeeGame() {
  // Game state
  const [currentRound, setCurrentRound] = useState(1)
  const [roundWords, setRoundWords] = useState([])
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [userInput, setUserInput] = useState("")
  const [score, setScore] = useState(0)
  const [gameActive, setGameActive] = useState(false)
  const [gameStarted, setGameStarted] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [roundOver, setRoundOver] = useState(false)
  const [showHint, setShowHint] = useState(false)
  const [hintsUsed, setHintsUsed] = useState(0)
  const [revealedLetters, setRevealedLetters] = useState([])
  const [studentId, setStudentId] = useState(null)

  // Timer state
  const [timeLeft, setTimeLeft] = useState(60) // 60 seconds for round 1
  const [timerActive, setTimerActive] = useState(false)

  // UI state
  const [theme, setTheme] = useState("default") // default, space, ocean, jungle
  const [showThemeSelector, setShowThemeSelector] = useState(false)
  const [showCelebration, setShowCelebration] = useState(false)
  const [showConfetti, setShowConfetti] = useState(false)
  const [achievements, setAchievements] = useState([])

  // Refs
  const inputRef = useRef(null)
  const timerRef = useRef(null)

  // Sound effects
  const correctSoundRef = useRef(null)
  const wrongSoundRef = useRef(null)
  const roundCompleteSoundRef = useRef(null)

  // Initialize game
  useEffect(() => {
    // Get current student ID for proper data isolation
    const username = localStorage.getItem("currentStudent")
    if (username) {
      const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
      const student = storedStudents.find((s) => s.username === username)
      if (student) {
        setStudentId(student.id)
      }
    }

    // Initialize sound effects
    if (typeof Audio !== "undefined") {
      correctSoundRef.current = new Audio("/correct.mp3")
      wrongSoundRef.current = new Audio("/wrong.mp3")
      roundCompleteSoundRef.current = new Audio("/level-up.mp3")
    }

    return () => {
      // Clean up timer on unmount
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [])

  // Start a new round
  const startRound = (roundNumber) => {
    // Set time limit based on round
    const timeLimit = roundNumber === 1 ? 60 : roundNumber === 2 ? 120 : 180
    setTimeLeft(timeLimit)

    // Get words for this round
    const roundKey = `round${roundNumber}`
    const allRoundWords = [...WORD_DATABASE[roundKey]]

    // Shuffle and pick 3 words
    for (let i = allRoundWords.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[allRoundWords[i], allRoundWords[j]] = [allRoundWords[j], allRoundWords[i]]
    }

    const selectedWords = allRoundWords.slice(0, 3)
    setRoundWords(selectedWords)
    setCurrentWordIndex(0)
    setRoundOver(false)
    setShowHint(false)
    setHintsUsed(0)
    setRevealedLetters([])
    setUserInput("")

    // Start the timer
    setTimerActive(true)
    setGameActive(true)

    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current)
          handleRoundEnd()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    // Focus on input
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus()
      }
    }, 100)
  }

  // Start the game
  const startGame = () => {
    setGameStarted(true)
    setGameActive(true)
    setGameOver(false)
    setScore(0)
    setCurrentRound(1)
    setAchievements([])
    startRound(1)
  }

  // Handle round end
  const handleRoundEnd = () => {
    clearInterval(timerRef.current)
    setTimerActive(false)
    setRoundOver(true)

    // Play sound
    if (roundCompleteSoundRef.current) {
      roundCompleteSoundRef.current.play().catch((e) => console.log("Error playing sound:", e))
    }

    // Check if this was the last round
    if (currentRound === 3) {
      handleGameOver()
    }
  }

  // Handle game over
  const handleGameOver = () => {
    setGameOver(true)
    setGameActive(false)
    saveGameData()

    // Add achievements based on score
    const newAchievements = []

    if (score >= 150) {
      newAchievements.push({ name: "Spelling Master", icon: "🏆", description: "Score 150+ points" })
    } else if (score >= 100) {
      newAchievements.push({ name: "Word Wizard", icon: "🧙", description: "Score 100+ points" })
    } else if (score >= 50) {
      newAchievements.push({ name: "Spelling Bee", icon: "🐝", description: "Score 50+ points" })
    }

    if (hintsUsed === 0) {
      newAchievements.push({
        name: "No Hints Needed",
        icon: "🧠",
        description: "Complete the game without using hints",
      })
    }

    setAchievements(newAchievements)
    setShowConfetti(true)
    setTimeout(() => setShowConfetti(false), 5000)
  }

  // Move to next round
  const moveToNextRound = () => {
    const nextRound = currentRound + 1
    setCurrentRound(nextRound)
    startRound(nextRound)
  }

  // Get current word data
  const getCurrentWord = () => {
    if (roundWords.length === 0) return { word: "", hint: "", definition: "" }
    return roundWords[currentWordIndex]
  }

  const currentWord = getCurrentWord().word || ""
  const currentHint = getCurrentWord().hint || ""

  // Handle user input
  const handleInputChange = (e) => {
    if (!gameActive) return
    setUserInput(e.target.value)
  }

  // Check answer
  const checkAnswer = () => {
    if (!gameActive || !currentWord) return

    if (userInput.toLowerCase() === currentWord.toLowerCase()) {
      // Correct answer
      const pointsPerWord = currentRound === 1 ? 10 : currentRound === 2 ? 20 : 30
      setScore(score + pointsPerWord)

      // Play sound
      if (correctSoundRef.current) {
        correctSoundRef.current.play().catch((e) => console.log("Error playing sound:", e))
      }

      // Show celebration animation
      setShowCelebration(true)
      setTimeout(() => setShowCelebration(false), 1500)

      toast({
        title: "Correct!",
        description: `You earned ${pointsPerWord} points!`,
      })

      // Move to next word or end round
      if (currentWordIndex < roundWords.length - 1) {
        setCurrentWordIndex(currentWordIndex + 1)
        setUserInput("")
        setShowHint(false)
        setRevealedLetters([])
      } else {
        // Round completed
        handleRoundEnd()
      }
    } else {
      // Incorrect answer
      // Play sound
      if (wrongSoundRef.current) {
        wrongSoundRef.current.play().catch((e) => console.log("Error playing sound:", e))
      }

      toast({
        title: "Try again",
        description: "That's not the correct spelling",
        variant: "destructive",
      })

      // Show hint after first incorrect attempt
      if (!showHint) {
        setShowHint(true)
        setHintsUsed(hintsUsed + 1)
      } else {
        // Reveal a letter after second incorrect attempt
        revealRandomLetter()
      }
    }
  }

  // Reveal a random letter in the word
  const revealRandomLetter = () => {
    if (!currentWord) return

    // Find positions that haven't been revealed yet
    const unrevealed = []
    for (let i = 0; i < currentWord.length; i++) {
      if (!revealedLetters.includes(i)) {
        unrevealed.push(i)
      }
    }

    if (unrevealed.length > 0) {
      // Randomly select one position to reveal
      const randomIndex = Math.floor(Math.random() * unrevealed.length)
      const positionToReveal = unrevealed[randomIndex]

      setRevealedLetters([...revealedLetters, positionToReveal])

      toast({
        title: "Letter Revealed",
        description: `The letter at position ${positionToReveal + 1} is "${currentWord[positionToReveal]}"`,
      })
    }
  }

  // Use hint
  const useHint = () => {
    setShowHint(true)
    setHintsUsed(hintsUsed + 1)
  }

  // Speak the current word
  const speakWord = () => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(currentWord)
      window.speechSynthesis.speak(utterance)
    }
  }

  // Save game data
  const saveGameData = () => {
    if (!studentId) return

    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const updatedStudents = storedStudents.map((student) => {
      if (student.id === studentId) {
        // Update student's game performance
        const gamePerformance = student.gamePerformance || {}
        const spellBeeData = gamePerformance["spell-bee"] || { played: 0, score: 0, level: 1 }

        return {
          ...student,
          gamePerformance: {
            ...gamePerformance,
            "spell-bee": {
              played: spellBeeData.played + 1,
              score: spellBeeData.score + score,
              level: Math.max(spellBeeData.level, currentRound),
            },
          },
          // Update overall progress based on all games
          progress: Math.min(100, student.progress + Math.floor(score / 5)),
        }
      }
      return student
    })

    localStorage.setItem("students", JSON.stringify(updatedStudents))
  }

  // Format time as MM:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  // Render blank spaces for the word
  const renderWordBlanks = () => {
    if (!currentWord) return null

    // For round 1, show first letter
    // For round 2, show first letter
    // For round 3, show first and last letter

    let initiallyRevealed = []

    if (currentRound === 1) {
      // No letters revealed initially
    } else if (currentRound === 2) {
      initiallyRevealed = [0] // First letter
    } else if (currentRound === 3) {
      initiallyRevealed = [0, currentWord.length - 1] // First and last letter
    }

    const allRevealed = [...new Set([...initiallyRevealed, ...revealedLetters])]

    return (
      <div className="flex justify-center space-x-2 mb-4">
        {currentWord.split("").map((letter, index) => (
          <div
            key={index}
            className={`w-10 h-10 border-b-2 border-orange-500 flex items-center justify-center text-xl font-bold
              ${allRevealed.includes(index) ? "text-orange-600" : "text-transparent"}
              transition-all duration-300 hover:scale-110 transform`}
          >
            {allRevealed.includes(index) ? letter : "."}
          </div>
        ))}
      </div>
    )
  }

  // Get theme-specific classes
  const getThemeClasses = () => {
    switch (theme) {
      case "space":
        return {
          background: "bg-gradient-to-b from-indigo-900 to-purple-900",
          card: "bg-indigo-800 border-purple-500 text-white",
          button: "bg-purple-600 hover:bg-purple-700",
          input: "bg-indigo-700 border-purple-500 text-white placeholder-purple-300",
          accent: "text-purple-300",
        }
      case "ocean":
        return {
          background: "bg-gradient-to-b from-blue-400 to-cyan-600",
          card: "bg-blue-50 border-blue-400",
          button: "bg-cyan-500 hover:bg-cyan-600",
          input: "bg-white border-blue-300",
          accent: "text-cyan-600",
        }
      case "jungle":
        return {
          background: "bg-gradient-to-b from-green-500 to-lime-600",
          card: "bg-green-50 border-green-400",
          button: "bg-lime-600 hover:bg-lime-700",
          input: "bg-white border-green-300",
          accent: "text-lime-700",
        }
      default:
        return {
          background: "bg-gradient-to-b from-orange-50 to-amber-50",
          card: "bg-white border-orange-300",
          button: "bg-orange-500 hover:bg-orange-600",
          input: "bg-white border-orange-300",
          accent: "text-orange-500",
        }
    }
  }

  const themeClasses = getThemeClasses()

  // Animated background elements
  const renderAnimatedBackground = () => {
    if (theme === "default") {
      return (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 text-6xl animate-float opacity-10">🐝</div>
          <div className="absolute top-3/4 left-3/4 text-5xl animate-float opacity-10" style={{ animationDelay: "1s" }}>
            🐝
          </div>
          <div className="absolute top-2/4 left-1/2 text-7xl animate-float opacity-10" style={{ animationDelay: "2s" }}>
            🐝
          </div>
          <div className="absolute top-1/3 left-2/3 text-5xl animate-float opacity-10" style={{ animationDelay: "3s" }}>
            🍯
          </div>
          <div className="absolute top-2/3 left-1/3 text-6xl animate-float opacity-10" style={{ animationDelay: "4s" }}>
            🌼
          </div>
        </div>
      )
    } else if (theme === "space") {
      return (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 text-6xl animate-pulse opacity-20">⭐</div>
          <div className="absolute top-3/4 left-3/4 text-5xl animate-pulse opacity-20" style={{ animationDelay: "1s" }}>
            🌟
          </div>
          <div className="absolute top-2/4 left-1/2 text-7xl animate-pulse opacity-20" style={{ animationDelay: "2s" }}>
            ✨
          </div>
          <div className="absolute top-1/3 left-2/3 text-5xl animate-pulse opacity-20" style={{ animationDelay: "3s" }}>
            🚀
          </div>
          <div className="absolute top-2/3 left-1/3 text-6xl animate-pulse opacity-20" style={{ animationDelay: "4s" }}>
            🌠
          </div>
        </div>
      )
    } else if (theme === "ocean") {
      return (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 text-6xl animate-bounce opacity-20">🐠</div>
          <div
            className="absolute top-3/4 left-3/4 text-5xl animate-bounce opacity-20"
            style={{ animationDelay: "1s" }}
          >
            🐙
          </div>
          <div
            className="absolute top-2/4 left-1/2 text-7xl animate-bounce opacity-20"
            style={{ animationDelay: "2s" }}
          >
            🐬
          </div>
          <div
            className="absolute top-1/3 left-2/3 text-5xl animate-bounce opacity-20"
            style={{ animationDelay: "3s" }}
          >
            🐚
          </div>
          <div
            className="absolute top-2/3 left-1/3 text-6xl animate-bounce opacity-20"
            style={{ animationDelay: "4s" }}
          >
            🌊
          </div>
        </div>
      )
    } else if (theme === "jungle") {
      return (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 text-6xl animate-sway opacity-20">🌴</div>
          <div className="absolute top-3/4 left-3/4 text-5xl animate-sway opacity-20" style={{ animationDelay: "1s" }}>
            🦁
          </div>
          <div className="absolute top-2/4 left-1/2 text-7xl animate-sway opacity-20" style={{ animationDelay: "2s" }}>
            🐘
          </div>
          <div className="absolute top-1/3 left-2/3 text-5xl animate-sway opacity-20" style={{ animationDelay: "3s" }}>
            🦒
          </div>
          <div className="absolute top-2/3 left-1/3 text-6xl animate-sway opacity-20" style={{ animationDelay: "4s" }}>
            🌿
          </div>
        </div>
      )
    }
  }

  // Render confetti for game over
  const renderConfetti = () => {
    if (!showConfetti) return null

    const confettiElements = []
    const colors = ["red", "blue", "green", "yellow", "purple", "orange"]

    for (let i = 0; i < 100; i++) {
      const left = `${Math.random() * 100}%`
      const animationDuration = `${Math.random() * 3 + 2}s`
      const animationDelay = `${Math.random() * 2}s`
      const color = colors[Math.floor(Math.random() * colors.length)]

      confettiElements.push(
        <div
          key={i}
          className={`absolute w-2 h-6 bg-${color}-500 rounded-full animate-confetti`}
          style={{
            left,
            top: "-20px",
            animationDuration,
            animationDelay,
            transform: `rotate(${Math.random() * 360}deg)`,
          }}
        />,
      )
    }

    return <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">{confettiElements}</div>
  }

  return (
    <div className={`min-h-screen ${themeClasses.background} transition-colors duration-500 relative`}>
      {/* Animated background */}
      {renderAnimatedBackground()}

      {/* Confetti animation */}
      {renderConfetti()}

      {/* Celebration animation */}
      {showCelebration && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-50">
          <div className="animate-bounce text-6xl">🎉</div>
          <div className="absolute top-1/4 left-1/4 animate-ping text-5xl delay-100">✨</div>
          <div className="absolute bottom-1/3 right-1/3 animate-ping text-5xl delay-300">🌟</div>
          <div className="absolute top-1/3 right-1/4 animate-ping text-5xl delay-500">⭐</div>
          <div className="absolute bottom-1/4 left-1/3 animate-ping text-5xl delay-700">🎊</div>
        </div>
      )}

      <header
        className={`${theme === "default" ? "bg-white" : themeClasses.card} shadow-md transition-colors duration-500 relative z-10`}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/dashboard">
              <Button variant="ghost" size="icon" className={theme !== "default" ? "text-white" : ""}>
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/dashboard" className="flex items-center space-x-2">
              <Home className={`h-5 w-5 ${themeClasses.accent}`} />
              <span className={`font-bold text-xl ${themeClasses.accent}`}>Spell Bee</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="bg-yellow-100 px-3 py-1 rounded-full flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="font-bold">{score}</span>
            </div>
            <div className="bg-blue-100 px-3 py-1 rounded-full">
              <span className="font-medium">Round: {currentRound}</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowThemeSelector(!showThemeSelector)}
              className="flex items-center"
            >
              <Sparkles className="h-4 w-4 mr-1" />
              Theme
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 relative z-10">
        {showThemeSelector && (
          <div className="max-w-2xl mx-auto mb-6 grid grid-cols-4 gap-4">
            <Button
              className={`h-16 ${theme === "default" ? "ring-4 ring-orange-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("default")}
            >
              <div className="w-full h-full bg-gradient-to-b from-orange-50 to-amber-50 rounded-md"></div>
            </Button>
            <Button
              className={`h-16 ${theme === "space" ? "ring-4 ring-purple-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("space")}
            >
              <div className="w-full h-full bg-gradient-to-b from-indigo-900 to-purple-900 rounded-md"></div>
            </Button>
            <Button
              className={`h-16 ${theme === "ocean" ? "ring-4 ring-blue-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("ocean")}
            >
              <div className="w-full h-full bg-gradient-to-b from-blue-400 to-cyan-600 rounded-md"></div>
            </Button>
            <Button
              className={`h-16 ${theme === "jungle" ? "ring-4 ring-green-400" : ""}`}
              variant="outline"
              onClick={() => setTheme("jungle")}
            >
              <div className="w-full h-full bg-gradient-to-b from-green-500 to-lime-600 rounded-md"></div>
            </Button>
          </div>
        )}

        <div className="max-w-2xl mx-auto">
          {!gameStarted ? (
            <Card className={`p-6 mb-6 shadow-lg border-2 ${themeClasses.card} transition-colors duration-500`}>
              <div className="text-center py-8">
                <h2 className={`text-3xl font-bold mb-6 ${theme === "space" ? "text-white" : ""}`}>
                  Spell Bee Challenge
                </h2>
                <div className="text-6xl mb-6 animate-bounce">🐝</div>
                <p className={`mb-6 ${theme === "space" ? "text-white" : ""}`}>
                  Test your spelling skills in three exciting rounds!
                </p>
                <div className="space-y-4 mb-8">
                  <div className={`p-4 rounded-lg ${theme === "space" ? "bg-indigo-700" : "bg-orange-50"}`}>
                    <h3 className={`font-bold ${theme === "space" ? "text-white" : ""}`}>
                      Round 1: Three-Letter Words
                    </h3>
                    <p className={`text-sm ${theme === "space" ? "text-indigo-200" : ""}`}>
                      1 minute • 10 points per word
                    </p>
                  </div>
                  <div className={`p-4 rounded-lg ${theme === "space" ? "bg-indigo-700" : "bg-orange-50"}`}>
                    <h3 className={`font-bold ${theme === "space" ? "text-white" : ""}`}>Round 2: Four-Letter Words</h3>
                    <p className={`text-sm ${theme === "space" ? "text-indigo-200" : ""}`}>
                      2 minutes • 20 points per word
                    </p>
                  </div>
                  <div className={`p-4 rounded-lg ${theme === "space" ? "bg-indigo-700" : "bg-orange-50"}`}>
                    <h3 className={`font-bold ${theme === "space" ? "text-white" : ""}`}>Round 3: Five-Letter Words</h3>
                    <p className={`text-sm ${theme === "space" ? "text-indigo-200" : ""}`}>
                      3 minutes • 30 points per word
                    </p>
                  </div>
                </div>
                <Button
                  onClick={startGame}
                  className={`${themeClasses.button} text-xl py-6 px-8 hover:scale-105 transition-transform`}
                >
                  Start Game
                </Button>
              </div>
            </Card>
          ) : gameOver ? (
            <Card
              className={`p-6 text-center animate-fadeIn ${themeClasses.card} border-2 transition-colors duration-500`}
            >
              <div className="py-4">
                <div className="flex justify-center mb-4">
                  <div className="text-6xl animate-bounce">🏆</div>
                </div>
                <h2 className={`text-2xl font-bold mb-4 ${theme === "space" ? "text-white" : ""}`}>Game Over!</h2>
                <p className={`mb-4 text-xl ${theme === "space" ? "text-white" : ""}`}>Your final score: {score}</p>

                {/* Achievements */}
                {achievements.length > 0 && (
                  <div className="mb-6">
                    <h3 className={`text-lg font-bold mb-2 ${theme === "space" ? "text-white" : ""}`}>
                      Achievements Unlocked:
                    </h3>
                    <div className="flex flex-wrap justify-center gap-4">
                      {achievements.map((achievement, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg ${theme === "space" ? "bg-indigo-700" : "bg-yellow-50"} animate-fadeIn`}
                          style={{ animationDelay: `${index * 0.3}s` }}
                        >
                          <div className="text-3xl mb-1">{achievement.icon}</div>
                          <div className={`font-bold ${theme === "space" ? "text-white" : ""}`}>{achievement.name}</div>
                          <div className={`text-xs ${theme === "space" ? "text-indigo-200" : "text-gray-600"}`}>
                            {achievement.description}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap justify-center gap-4 mb-6">
                  <div className="animate-bounce delay-100">🎉</div>
                  <div className="animate-bounce delay-200">🎊</div>
                  <div className="animate-bounce delay-300">🌟</div>
                  <div className="animate-bounce delay-400">✨</div>
                  <div className="animate-bounce delay-500">🏅</div>
                </div>

                <div className="flex space-x-4 justify-center">
                  <Link href="/student/dashboard">
                    <Button variant="outline" className="hover:scale-105 transition-transform">
                      Back to Dashboard
                    </Button>
                  </Link>
                  <Button
                    onClick={() => {
                      setGameStarted(false)
                      setGameOver(false)
                      setScore(0)
                      setCurrentRound(1)
                      setAchievements([])
                    }}
                    className={`${themeClasses.button} hover:scale-105 transition-transform`}
                  >
                    Play Again
                  </Button>
                </div>
              </div>
            </Card>
          ) : roundOver ? (
            <Card
              className={`p-6 text-center animate-fadeIn ${themeClasses.card} border-2 transition-colors duration-500`}
            >
              <div className="py-4">
                <div className="flex justify-center mb-4">
                  <div className="text-6xl animate-bounce">{currentRound === 3 ? "🏆" : "🎯"}</div>
                </div>
                <h2 className={`text-2xl font-bold mb-4 ${theme === "space" ? "text-white" : ""}`}>
                  Round {currentRound} Complete!
                </h2>
                <p className={`mb-4 text-xl ${theme === "space" ? "text-white" : ""}`}>Current score: {score}</p>

                {currentRound < 3 ? (
                  <div className="mb-6">
                    <h3 className={`text-lg font-bold mb-2 ${theme === "space" ? "text-white" : ""}`}>Next Round:</h3>
                    <div className={`p-4 rounded-lg ${theme === "space" ? "bg-indigo-700" : "bg-orange-50"}`}>
                      <h3 className={`font-bold ${theme === "space" ? "text-white" : ""}`}>
                        Round {currentRound + 1}: {currentRound + 1 === 2 ? "Four" : "Five"}-Letter Words
                      </h3>
                      <p className={`text-sm ${theme === "space" ? "text-indigo-200" : ""}`}>
                        {currentRound + 1 === 2 ? "2 minutes" : "3 minutes"} • {currentRound + 1 === 2 ? "20" : "30"}{" "}
                        points per word
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="mb-6">
                    <h3 className={`text-lg font-bold mb-2 ${theme === "space" ? "text-white" : ""}`}>
                      All rounds completed!
                    </h3>
                  </div>
                )}

                <Button
                  onClick={currentRound < 3 ? moveToNextRound : handleGameOver}
                  className={`${themeClasses.button} hover:scale-105 transition-transform`}
                >
                  {currentRound < 3 ? "Next Round" : "See Final Results"}
                </Button>
              </div>
            </Card>
          ) : (
            <Card className={`p-6 mb-6 shadow-lg border-2 ${themeClasses.card} transition-colors duration-500`}>
              <div className="flex justify-between items-center mb-4">
                <h2 className={`text-xl font-bold ${theme !== "default" && theme === "space" ? "text-white" : ""}`}>
                  Round {currentRound}: Spell the Word
                </h2>
                <div className="flex items-center space-x-2">
                  <div
                    className={`px-3 py-1 rounded-full flex items-center ${theme === "space" ? "bg-indigo-700" : "bg-red-100"}`}
                  >
                    <Clock className={`h-4 w-4 mr-1 ${theme === "space" ? "text-indigo-300" : "text-red-500"}`} />
                    <span className={`font-bold ${theme === "space" ? "text-white" : ""}`}>{formatTime(timeLeft)}</span>
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={speakWord}
                    className="rounded-full hover:scale-110 transition-transform"
                  >
                    <Volume2 className="h-5 w-5 text-blue-500" />
                  </Button>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="rounded-full hover:scale-110 transition-transform"
                      >
                        <HelpCircle className="h-5 w-5 text-purple-500" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>How to Play</DialogTitle>
                        <DialogDescription>
                          <p className="mb-2">1. Listen to the word by clicking the speaker icon</p>
                          <p className="mb-2">2. Type the correct spelling in the box</p>
                          <p className="mb-2">3. Click "Check" to see if you're right</p>
                          <p className="mb-2">4. Complete all words before the timer runs out</p>
                          <p className="mb-2">5. Use hints if you need help</p>
                          <p>6. Each round has different difficulty words and time limits</p>
                        </DialogDescription>
                      </DialogHeader>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className={theme === "space" ? "text-white" : ""}>
                    Word {currentWordIndex + 1} of {roundWords.length}
                  </span>
                  <span className={theme === "space" ? "text-white" : ""}>
                    {currentRound === 1 ? "3-letter words" : currentRound === 2 ? "4-letter words" : "5-letter words"}
                  </span>
                </div>
                <Progress value={(currentWordIndex / roundWords.length) * 100} className="h-2" />
              </div>

              {/* Timer */}
              <div className="mb-4">
                <Progress
                  value={(timeLeft / (currentRound === 1 ? 60 : currentRound === 2 ? 120 : 180)) * 100}
                  className="h-2 bg-gray-200"
                >
                  <div
                    className={`h-full transition-all duration-1000 ${timeLeft < 10 ? "bg-red-500 animate-pulse" : "bg-green-500"}`}
                    style={{
                      width: `${(timeLeft / (currentRound === 1 ? 60 : currentRound === 2 ? 120 : 180)) * 100}%`,
                    }}
                  ></div>
                </Progress>
              </div>

              {/* Word display */}
              <div
                className={`${theme === "space" ? "bg-indigo-700" : "bg-orange-50"} p-6 rounded-lg mb-6 text-center transition-colors duration-500`}
              >
                <div className={`mb-2 text-sm ${theme === "space" ? "text-indigo-200" : "text-gray-500"}`}>
                  Click the speaker to hear the word:
                </div>
                <Button
                  onClick={speakWord}
                  className={`${themeClasses.button} h-16 w-16 rounded-full hover:scale-110 transition-transform animate-bounce`}
                  size="icon"
                >
                  <Volume2 className="h-8 w-8" />
                </Button>

                {/* Word blanks */}
                <div className="mt-6">{renderWordBlanks()}</div>

                {/* Enhanced bee animation */}
                <div className="relative h-16 mt-4">
                  <div className="absolute left-1/2 transform -translate-x-1/2 animate-[bounce_2s_infinite]">
                    <div className="text-4xl transform hover:scale-125 transition-transform duration-300 animate-[wiggle_1s_ease-in-out_infinite]">
                      🐝
                    </div>
                  </div>
                  <div className="absolute left-1/3 top-2 transform -translate-x-1/2 animate-[bounce_3s_infinite_0.5s]">
                    <div className="text-3xl transform rotate-12">🐝</div>
                  </div>
                  <div className="absolute left-2/3 top-4 transform -translate-x-1/2 animate-[bounce_2.5s_infinite_1s]">
                    <div className="text-3xl transform -rotate-12">🐝</div>
                  </div>
                </div>
              </div>

              {/* Hint */}
              {showHint && (
                <div
                  className={`${theme === "space" ? "bg-indigo-700 text-white" : "bg-yellow-50 text-yellow-800"} p-3 rounded-lg mb-4 text-center animate-fadeIn transition-colors duration-500`}
                >
                  <div className="flex items-center justify-center">
                    <Lightbulb className="h-5 w-5 mr-2" />
                    <p className="text-sm">Hint: {currentHint}</p>
                  </div>
                </div>
              )}

              {/* User input */}
              <div className="mb-6">
                <div className="flex space-x-2">
                  <input
                    ref={inputRef}
                    type="text"
                    value={userInput}
                    onChange={handleInputChange}
                    placeholder="Type the spelling..."
                    className={`flex-1 px-4 py-2 border-2 rounded-lg text-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all ${themeClasses.input}`}
                    disabled={!gameActive}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        checkAnswer()
                      }
                    }}
                  />
                  <Button
                    onClick={checkAnswer}
                    disabled={!gameActive || !userInput}
                    className={`${themeClasses.button} hover:scale-105 transition-all`}
                  >
                    Check
                  </Button>
                </div>
              </div>

              {/* Controls */}
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  className={`flex-1 hover:bg-orange-100 transition-colors ${theme === "space" ? "text-white hover:bg-indigo-700" : ""}`}
                  onClick={speakWord}
                  disabled={!gameActive}
                >
                  <Volume2 className="h-4 w-4 mr-2" />
                  Hear Again
                </Button>
                <Button
                  variant="outline"
                  className={`flex-1 hover:bg-yellow-100 transition-colors ${theme === "space" ? "text-white hover:bg-indigo-700" : ""}`}
                  onClick={useHint}
                  disabled={showHint || !gameActive}
                >
                  <Lightbulb className="h-4 w-4 mr-2" />
                  Hint
                </Button>
                <Button
                  variant="outline"
                  className={`flex-1 hover:bg-blue-100 transition-colors ${theme === "space" ? "text-white hover:bg-indigo-700" : ""}`}
                  onClick={revealRandomLetter}
                  disabled={!gameActive || revealedLetters.length >= currentWord.length - 1}
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Reveal Letter
                </Button>
              </div>
            </Card>
          )}
        </div>
      </main>
      <EmotionCapture
        onEmotionData={(data) => {
          // In a real app, we would use this data to adapt the game
          console.log("Emotion data:", data)

          // Example of adapting the game based on emotions:
          if (data.emotion === "frustrated" && data.intensity > 70) {
            // If the student seems frustrated, we could show a hint
            if (!showHint) {
              setShowHint(true)
              toast({
                title: "Need some help?",
                description: "Here's a hint to help you out!",
              })
            }
          }
        }}
        gameId="spell-bee"
        studentId={studentId}
        active={gameActive}
      />
    </div>
  )
}

