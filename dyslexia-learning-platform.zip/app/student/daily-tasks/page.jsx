"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Home, Star, Calendar, CheckCircle, Trophy, Flame, Gift, Award } from "lucide-react"
import { useRouter } from "next/navigation"
import confetti from "canvas-confetti"

// Task definitions with varying difficulty levels
const DAILY_TASKS = [
  {
    id: 1,
    title: "Complete a Word Builder game",
    description: "Play one round of Word Builder",
    points: 10,
    type: "game",
    game: "word-builder",
    difficulty: "easy",
    icon: "📝",
  },
  {
    id: 2,
    title: "Spell 5 words correctly",
    description: "Get 5 words right in Spell Bee",
    points: 15,
    type: "game",
    game: "spell-bee",
    difficulty: "easy",
    icon: "🐝",
  },
  {
    id: 3,
    title: "Complete Memory Matching",
    description: "Play one round of Memory Matching",
    points: 10,
    type: "game",
    game: "memory-matching",
    difficulty: "medium",
    icon: "🧠",
  },
  {
    id: 4,
    title: "Read a short story",
    description: "Read the daily story and answer questions",
    points: 20,
    type: "reading",
    difficulty: "medium",
    icon: "📚",
  },
  {
    id: 5,
    title: "Practice writing",
    description: "Write 3 sentences about your day",
    points: 15,
    type: "writing",
    difficulty: "medium",
    icon: "✏️",
  },
  {
    id: 6,
    title: "Learn 3 new words",
    description: "Add 3 new words to your vocabulary",
    points: 15,
    type: "vocabulary",
    difficulty: "hard",
    icon: "📖",
  },
  {
    id: 7,
    title: "Complete Sound Match",
    description: "Play one round of Sound Match",
    points: 10,
    type: "game",
    game: "sound-match",
    difficulty: "medium",
    icon: "🔊",
  },
  {
    id: 8,
    title: "Rhyme Time challenge",
    description: "Score 50+ points in Rhyme Time",
    points: 20,
    type: "game",
    game: "rhyme-time",
    difficulty: "hard",
    icon: "🎵",
  },
  {
    id: 9,
    title: "Word Scramble master",
    description: "Unscramble 10 words correctly",
    points: 25,
    type: "game",
    game: "word-scramble",
    difficulty: "hard",
    icon: "🔤",
  },
  {
    id: 10,
    title: "Daily spelling test",
    description: "Take today's spelling test",
    points: 30,
    type: "test",
    difficulty: "hard",
    icon: "📝",
  },
]

export default function DailyTasksPage() {
  const [studentName, setStudentName] = useState("")
  const [dailyTasks, setDailyTasks] = useState([])
  const [completedTasks, setCompletedTasks] = useState([])
  const [streakCount, setStreakCount] = useState(0)
  const [totalPoints, setTotalPoints] = useState(0)
  const [todayPoints, setTodayPoints] = useState(0)
  const [loading, setLoading] = useState(true)
  const [showReward, setShowReward] = useState(false)
  const [reward, setReward] = useState(null)
  const router = useRouter()

  // Initialize data
  useEffect(() => {
    const username = localStorage.getItem("currentStudent")
    if (!username) {
      router.push("/student/login")
      return
    }

    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const student = storedStudents.find((s) => s.username === username)

    if (student) {
      setStudentName(student.name)

      // Load or initialize daily tasks data
      const storedTaskData = localStorage.getItem(`dailyTasks_${student.id}`)

      if (storedTaskData) {
        const taskData = JSON.parse(storedTaskData)

        // Check if tasks are from today
        const today = new Date().toDateString()

        if (taskData.date === today) {
          // Use today's existing data
          setDailyTasks(taskData.tasks)
          setCompletedTasks(taskData.completed || [])
          setStreakCount(taskData.streak || 0)
          setTotalPoints(taskData.totalPoints || 0)
          setTodayPoints(taskData.todayPoints || 0)
        } else {
          // It's a new day, generate new tasks
          generateNewDailyTasks(student.id, taskData.streak, taskData.totalPoints)
        }
      } else {
        // First time user, generate initial tasks
        generateNewDailyTasks(student.id, 0, 0)
      }
    } else {
      router.push("/student/login")
    }

    setLoading(false)
  }, [router])

  // Generate new daily tasks
  const generateNewDailyTasks = (studentId, currentStreak, currentTotalPoints) => {
    // Check if streak should continue or reset
    const lastCompletionDate = localStorage.getItem(`lastTaskCompletion_${studentId}`)
    const yesterday = new Date()
    yesterday.setDate(yesterday.getDate() - 1)
    const yesterdayString = yesterday.toDateString()

    let newStreak = currentStreak

    if (lastCompletionDate !== yesterdayString) {
      // Streak broken, reset to 0
      newStreak = 0
    }

    // Select 5 random tasks from the pool
    const shuffled = [...DAILY_TASKS].sort(() => 0.5 - Math.random())
    const selectedTasks = shuffled.slice(0, 5)

    // Initialize task data
    const taskData = {
      date: new Date().toDateString(),
      tasks: selectedTasks,
      completed: [],
      streak: newStreak,
      totalPoints: currentTotalPoints,
      todayPoints: 0,
    }

    // Save to localStorage
    localStorage.setItem(`dailyTasks_${studentId}`, JSON.stringify(taskData))

    // Update state
    setDailyTasks(selectedTasks)
    setCompletedTasks([])
    setStreakCount(newStreak)
    setTotalPoints(currentTotalPoints)
    setTodayPoints(0)
  }

  // Complete a task
  const completeTask = (taskId) => {
    if (completedTasks.includes(taskId)) return

    const task = dailyTasks.find((t) => t.id === taskId)
    if (!task) return

    // Update completed tasks
    const newCompletedTasks = [...completedTasks, taskId]
    setCompletedTasks(newCompletedTasks)

    // Update points
    const newTodayPoints = todayPoints + task.points
    setTodayPoints(newTodayPoints)
    setTotalPoints(totalPoints + task.points)

    // Get student ID
    const username = localStorage.getItem("currentStudent")
    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const student = storedStudents.find((s) => s.username === username)

    if (!student) return

    // Update task data in localStorage
    const taskData = {
      date: new Date().toDateString(),
      tasks: dailyTasks,
      completed: newCompletedTasks,
      streak: streakCount,
      totalPoints: totalPoints + task.points,
      todayPoints: newTodayPoints,
    }

    localStorage.setItem(`dailyTasks_${student.id}`, JSON.stringify(taskData))

    // Check if all tasks are completed
    if (newCompletedTasks.length === dailyTasks.length) {
      // All tasks completed!
      const newStreak = streakCount + 1
      setStreakCount(newStreak)

      // Update streak in localStorage
      taskData.streak = newStreak
      localStorage.setItem(`dailyTasks_${student.id}`, JSON.stringify(taskData))

      // Set last completion date
      localStorage.setItem(`lastTaskCompletion_${student.id}`, new Date().toDateString())

      // Show celebration
      if (typeof window !== "undefined") {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        })
      }

      // Show reward
      generateReward(newStreak)
    }

    // Show toast
    toast({
      title: "Task completed!",
      description: `You earned ${task.points} points!`,
    })
  }

  // Generate a reward based on streak
  const generateReward = (streak) => {
    let rewardItem

    if (streak >= 7) {
      // Weekly reward
      const weeklyRewards = [
        { name: "Golden Trophy", icon: "🏆", description: "You've completed tasks for a whole week!" },
        { name: "Super Star", icon: "⭐", description: "You're a superstar! Keep up the great work!" },
        { name: "Champion Badge", icon: "🥇", description: "You're a daily task champion!" },
      ]
      rewardItem = weeklyRewards[Math.floor(Math.random() * weeklyRewards.length)]
    } else {
      // Daily reward
      const dailyRewards = [
        { name: "Star Points", icon: "⭐", description: "Extra points for your collection!" },
        { name: "Streak Booster", icon: "🔥", description: "Your streak is growing!" },
        { name: "Achievement Badge", icon: "🏅", description: "You completed all daily tasks!" },
      ]
      rewardItem = dailyRewards[Math.floor(Math.random() * dailyRewards.length)]
    }

    setReward(rewardItem)
    setShowReward(true)
  }

  // Navigate to a game
  const navigateToGame = (game) => {
    router.push(`/student/games/${game}`)
  }

  // Get difficulty color
  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case "easy":
        return "text-green-500"
      case "medium":
        return "text-yellow-500"
      case "hard":
        return "text-red-500"
      default:
        return "text-gray-500"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading your daily tasks...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/dashboard" className="flex items-center space-x-2">
              <Home className="h-5 w-5 text-blue-500" />
              <span className="font-bold text-xl text-blue-500">Daily Tasks</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="bg-yellow-100 px-3 py-1 rounded-full flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="font-bold">{totalPoints}</span>
            </div>
            <div className="bg-red-100 px-3 py-1 rounded-full flex items-center">
              <Flame className="h-4 w-4 text-red-500 mr-1" />
              <span className="font-bold">{streakCount} day streak</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-8 bg-white shadow-lg border-2 border-blue-300">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl">Daily Tasks for {studentName}</CardTitle>
                  <CardDescription>Complete all tasks to maintain your streak!</CardDescription>
                </div>
                <div className="flex items-center space-x-2 bg-blue-100 px-3 py-2 rounded-lg">
                  <Calendar className="h-5 w-5 text-blue-500" />
                  <span className="font-medium">{new Date().toLocaleDateString()}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1">
                  <span>Today's Progress</span>
                  <span>
                    {completedTasks.length}/{dailyTasks.length} Tasks Completed
                  </span>
                </div>
                <Progress value={(completedTasks.length / dailyTasks.length) * 100} className="h-3" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                {dailyTasks.map((task) => (
                  <Card
                    key={task.id}
                    className={`border-2 transition-all ${
                      completedTasks.includes(task.id)
                        ? "bg-green-50 border-green-300"
                        : "bg-white border-gray-200 hover:border-blue-300 hover:shadow-md"
                    }`}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center">
                          <div className="text-3xl mr-3">{task.icon}</div>
                          <CardTitle>{task.title}</CardTitle>
                        </div>
                        <div className={`text-xs font-medium ${getDifficultyColor(task.difficulty)}`}>
                          {task.difficulty.toUpperCase()}
                        </div>
                      </div>
                      <CardDescription>{task.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Trophy className="h-4 w-4 text-yellow-500 mr-1" />
                          <span className="text-sm font-medium">{task.points} points</span>
                        </div>
                        {task.type === "game" && (
                          <Button size="sm" variant="outline" onClick={() => navigateToGame(task.game)}>
                            Play Game
                          </Button>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button
                        className={`w-full ${
                          completedTasks.includes(task.id)
                            ? "bg-green-500 hover:bg-green-600"
                            : "bg-blue-500 hover:bg-blue-600"
                        }`}
                        onClick={() => completeTask(task.id)}
                        disabled={completedTasks.includes(task.id)}
                      >
                        {completedTasks.includes(task.id) ? (
                          <>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Completed
                          </>
                        ) : (
                          "Mark as Complete"
                        )}
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Streak information */}
          <Card className="mb-8 bg-white shadow-lg border-2 border-red-300">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Flame className="h-5 w-5 text-red-500 mr-2" />
                Your Streak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center">
                <div className="text-6xl font-bold text-red-500 mb-4">{streakCount}</div>
                <p className="text-gray-600 mb-4">
                  {streakCount === 0
                    ? "Start your streak by completing all daily tasks!"
                    : `You've completed daily tasks for ${streakCount} day${streakCount > 1 ? "s" : ""} in a row!`}
                </p>

                <div className="flex space-x-2 mb-6">
                  {[...Array(7)].map((_, i) => (
                    <div
                      key={i}
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        i < (streakCount % 7) ? "bg-red-500 text-white" : "bg-gray-200"
                      }`}
                    >
                      {i + 1}
                    </div>
                  ))}
                </div>

                <div className="text-sm text-gray-500">Complete 7 days in a row to earn special rewards!</div>
              </div>
            </CardContent>
          </Card>

          {/* Rewards section */}
          <Card className="bg-white shadow-lg border-2 border-yellow-300">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Gift className="h-5 w-5 text-yellow-500 mr-2" />
                Rewards & Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-2 border-yellow-200 bg-yellow-50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Total Points</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-yellow-500 mb-2">{totalPoints}</div>
                      <p className="text-sm text-gray-600">Lifetime points earned</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-blue-200 bg-blue-50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Today's Points</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-blue-500 mb-2">{todayPoints}</div>
                      <p className="text-sm text-gray-600">Points earned today</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-purple-200 bg-purple-50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Achievements</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-purple-500 mb-2">
                        <Award className="h-10 w-10 inline-block" />
                      </div>
                      <p className="text-sm text-gray-600">
                        {streakCount >= 7 ? "Weekly Streak Champion!" : "Complete daily tasks to earn achievements"}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Reward popup */}
      {showReward && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full text-center animate-bounce-in">
            <div className="text-6xl mb-4">{reward.icon}</div>
            <h2 className="text-2xl font-bold mb-2">{reward.name}</h2>
            <p className="text-gray-600 mb-6">{reward.description}</p>
            <Button className="bg-yellow-500 hover:bg-yellow-600" onClick={() => setShowReward(false)}>
              Claim Reward
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

