"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { toast } from "@/hooks/use-toast"
import { MessageCircle, Home, ArrowLeft, Send } from "lucide-react"

export default function StudentMessages() {
  const [student, setStudent] = useState(null)
  const [therapist, setTherapist] = useState(null)
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Load student data
    const username = localStorage.getItem("currentStudent")
    if (!username) {
      router.push("/student/login")
      return
    }

    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const currentStudent = storedStudents.find((s) => s.username === username)

    if (!currentStudent) {
      router.push("/student/login")
      return
    }

    setStudent(currentStudent)
    setMessages(currentStudent.messages || [])

    // Find assigned therapist
    const therapists = JSON.parse(localStorage.getItem("therapists") || "[]")
    const assignedTherapist = therapists.find(
      (t) => t.assignedStudents && t.assignedStudents.includes(currentStudent.id),
    )

    if (assignedTherapist) {
      setTherapist(assignedTherapist)
    }

    setIsLoading(false)
  }, [router])

  const handleSendMessage = () => {
    if (!newMessage.trim() || !student) return

    const message = {
      id: Date.now(),
      text: newMessage,
      date: new Date().toISOString(),
      from: "student",
    }

    // Update local state
    setMessages([...messages, message])
    setNewMessage("")

    // Update in localStorage
    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const updatedStudents = storedStudents.map((s) => {
      if (s.id === student.id) {
        return {
          ...s,
          messages: [...(s.messages || []), message],
        }
      }
      return s
    })

    localStorage.setItem("students", JSON.stringify(updatedStudents))

    toast({
      title: "Message sent",
      description: "Your message has been sent to your mentor.",
    })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading messages...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/student/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <Link href="/student/dashboard" className="flex items-center space-x-2">
              <Home className="h-5 w-5 text-blue-500" />
              <span className="font-bold text-xl text-blue-500">Messages</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <MessageCircle className="h-5 w-5 text-blue-500" />
                <CardTitle>Messages with Your Mentor</CardTitle>
              </div>
              <CardDescription>
                {therapist ? `Chat with ${therapist.name}` : "You don't have an assigned mentor yet"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto p-2">
                {messages.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-30" />
                    <p>No messages yet. Send a message to your mentor!</p>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`p-3 rounded-lg ${msg.from === "student" ? "bg-blue-100 ml-12" : "bg-gray-100 mr-12"}`}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">
                          {msg.from === "student" ? "You" : therapist ? therapist.name : "Mentor"}
                        </span>
                        <span className="text-xs text-gray-500">{new Date(msg.date).toLocaleString()}</span>
                      </div>
                      <p>{msg.text}</p>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
            <CardFooter>
              <div className="flex w-full space-x-2">
                <Input
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSendMessage()
                    }
                  }}
                />
                <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                  <Send className="h-4 w-4 mr-2" />
                  Send
                </Button>
              </div>
            </CardFooter>
          </Card>

          <div className="text-center">
            <Link href="/student/dashboard">
              <Button variant="outline">Back to Dashboard</Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}

