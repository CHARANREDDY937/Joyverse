"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  BookOpen,
  Brain,
  Music,
  Puzzle,
  Shuffle,
  Trophy,
  Home,
  Volume2,
  LogOut,
  MessageCircle,
  Calendar,
  Flame,
} from "lucide-react"
import { useRouter } from "next/navigation"

export default function StudentDashboard() {
  const [studentName, setStudentName] = useState("")
  const [level, setLevel] = useState(1)
  const [xp, setXp] = useState(0)
  const [nextLevelXp, setNextLevelXp] = useState(500)
  const [messages, setMessages] = useState([])
  const [therapistName, setTherapistName] = useState("Not Assigned")
  const [gamePerformance, setGamePerformance] = useState({})
  const [streakCount, setStreakCount] = useState(0)
  const [dailyTasksCompleted, setDailyTasksCompleted] = useState(0)
  const [totalDailyTasks, setTotalDailyTasks] = useState(5)
  const router = useRouter()

  useEffect(() => {
    // Clear any previous student data to prevent persistence issues
    const username = localStorage.getItem("currentStudent")
    if (!username) {
      router.push("/student/login")
      return
    }

    const storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const student = storedStudents.find((s) => s.username === username)

    if (student) {
      setStudentName(student.name)
      setLevel(student.level || 1)
      setXp(student.progress * 5 || 0)
      setNextLevelXp(500)
      setMessages(student.messages || [])
      setGamePerformance(student.gamePerformance || {})

      // Find assigned therapist
      const therapists = JSON.parse(localStorage.getItem("therapists") || "[]")
      const assignedTherapist = therapists.find((t) => t.assignedStudents && t.assignedStudents.includes(student.id))

      if (assignedTherapist) {
        setTherapistName(assignedTherapist.name)
      }

      // Load daily tasks data
      const storedTaskData = localStorage.getItem(`dailyTasks_${student.id}`)
      if (storedTaskData) {
        const taskData = JSON.parse(storedTaskData)
        setStreakCount(taskData.streak || 0)
        setDailyTasksCompleted(taskData.completed?.length || 0)
        setTotalDailyTasks(taskData.tasks?.length || 5)
      }
    } else {
      router.push("/student/login")
    }
  }, [router])

  const games = [
    {
      id: "word-builder",
      title: "Word Builder",
      description: "Build words from letters",
      icon: <BookOpen className="h-8 w-8 text-green-500" />,
      color: "bg-green-100 border-green-300",
      iconBg: "bg-green-200",
      path: "/student/games/word-builder",
    },
    {
      id: "memory-matching",
      title: "Memory Matching",
      description: "Match pairs of cards",
      icon: <Brain className="h-8 w-8 text-purple-500" />,
      color: "bg-purple-100 border-purple-300",
      iconBg: "bg-purple-200",
      path: "/student/games/memory-matching",
    },
    {
      id: "sound-match",
      title: "Sound Match",
      description: "Match sounds with words",
      icon: <Music className="h-8 w-8 text-blue-500" />,
      color: "bg-blue-100 border-blue-300",
      iconBg: "bg-blue-200",
      path: "/student/games/sound-match",
    },
    {
      id: "rhyme-time",
      title: "Rhyme Time",
      description: "Find words that rhyme",
      icon: <Puzzle className="h-8 w-8 text-red-500" />,
      color: "bg-red-100 border-red-300",
      iconBg: "bg-red-200",
      path: "/student/games/rhyme-time",
    },
    {
      id: "word-scramble",
      title: "Word Scramble",
      description: "Unscramble the letters",
      icon: <Shuffle className="h-8 w-8 text-yellow-500" />,
      color: "bg-yellow-100 border-yellow-300",
      iconBg: "bg-yellow-200",
      path: "/student/games/word-scramble",
    },
    {
      id: "spell-bee",
      title: "Spell Bee",
      description: "Spell words correctly",
      icon: <Volume2 className="h-8 w-8 text-orange-500" />,
      color: "bg-orange-100 border-orange-300",
      iconBg: "bg-orange-200",
      path: "/student/games/spell-bee",
    },
  ]

  const handleLogout = () => {
    localStorage.removeItem("currentStudent")
    router.push("/")
  }

  // Calculate game progress for each game
  const getGameProgress = (gameId) => {
    if (!gamePerformance || !gamePerformance[gameId]) {
      return 0
    }

    const game = gamePerformance[gameId]
    if (game.played === 0) return 0

    // Calculate progress based on score and level
    return Math.min(100, Math.round(game.score / 10 + (game.level - 1) * 25))
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-500" />
            <span className="font-bold text-xl text-blue-500">PlayLearn</span>
          </Link>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="font-bold text-gray-800">{studentName}</div>
              <div className="text-sm text-gray-500">Level {level}</div>
            </div>
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Student avatar"
                width={40}
                height={40}
                className="rounded-full"
              />
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Welcome back, {studentName}!</h2>
              <p className="text-gray-600">Ready to play and learn today?</p>
              <p className="text-sm text-gray-500 mt-1">Your mentor: {therapistName}</p>
            </div>
            <div className="flex items-center space-x-2">
              <Trophy className="h-6 w-6 text-yellow-500" />
              <span className="font-bold text-yellow-500">{xp} XP</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Level {level}</span>
              <span>
                {xp}/{nextLevelXp} XP to Level {level + 1}
              </span>
            </div>
            <Progress value={(xp / nextLevelXp) * 100} className="h-3" />
          </div>
        </div>

        {/* Daily Tasks Card */}
        <div className="mb-6">
          <Link href="/student/daily-tasks">
            <Card className="border-2 border-yellow-400 hover:shadow-lg transition-all hover:scale-105 bg-gradient-to-r from-yellow-50 to-orange-50">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <div className="p-3 rounded-lg bg-yellow-200">
                      <Calendar className="h-8 w-8 text-yellow-600" />
                    </div>
                    <div className="ml-4">
                      <CardTitle className="text-xl">Daily Tasks</CardTitle>
                      <CardDescription>Complete tasks to earn rewards</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Flame className="h-5 w-5 text-red-500" />
                    <span className="font-medium text-red-500">{streakCount} day streak</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Today's Progress</span>
                    <span>
                      {dailyTasksCompleted}/{totalDailyTasks} Tasks
                    </span>
                  </div>
                  <Progress value={(dailyTasksCompleted / totalDailyTasks) * 100} className="h-2" />
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-yellow-500 hover:bg-yellow-600">View Daily Tasks</Button>
              </CardFooter>
            </Card>
          </Link>
        </div>

        {/* Mentor Messages Button - Prominently displayed */}
        <div className="mb-6">
          <Link href="/student/messages">
            <Button className="w-full py-6 text-lg bg-blue-500 hover:bg-blue-600 group">
              <MessageCircle className="h-6 w-6 mr-3 group-hover:animate-bounce" />
              <span>View Messages from Your Mentor ({messages.length})</span>
            </Button>
          </Link>
        </div>

        <h2 className="text-2xl font-bold text-gray-800 mb-6">Choose a Game</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game) => (
            <Link href={game.path} key={game.id}>
              <Card className={`border-2 hover:shadow-lg transition-all hover:scale-105 ${game.color}`}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className={`p-3 rounded-lg ${game.iconBg}`}>{game.icon}</div>
                    <div className="text-sm font-medium text-gray-500">Level {level}</div>
                  </div>
                  <CardTitle className="mt-4 text-xl">{game.title}</CardTitle>
                  <CardDescription>{game.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{getGameProgress(game.id)}%</span>
                    </div>
                    <Progress value={getGameProgress(game.id)} className="h-2" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Play Now</Button>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}

