"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/hooks/use-toast"

export default function StudentLogin() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Updated login function with better error handling
  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // For demo purposes, we'll check against the stored students
      await new Promise((resolve) => setTimeout(resolve, 1000))

      console.log("Attempting login with:", { username, password })

      // Add a default student if none exists for testing
      let storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
      console.log("Initial stored students:", storedStudents)

      // Always ensure the test student exists
      const testStudentExists = storedStudents.some((s) => s.username === "student")

      if (!testStudentExists) {
        console.log("Test student not found, creating one...")
        const testStudent = {
          id: storedStudents.length > 0 ? Math.max(...storedStudents.map((s) => s.id)) + 1 : 1,
          name: "Test Student",
          username: "student",
          password: "password",
          age: 8,
          level: 1,
          lastActive: "Never",
          progress: 0,
          gamePerformance: {
            "word-builder": { played: 0, score: 0, level: 1 },
            "memory-matching": { played: 0, score: 0, level: 1 },
            "sound-match": { played: 0, score: 0, level: 1 },
            "rhyme-time": { played: 0, score: 0, level: 1 },
            "word-scramble": { played: 0, score: 0, level: 1 },
            "spell-bee": { played: 0, score: 0, level: 1 },
          },
          messages: [],
        }

        storedStudents.push(testStudent)
        localStorage.setItem("students", JSON.stringify(storedStudents))
        console.log("Added test student:", testStudent)
      }

      // Re-fetch students to ensure we have the latest data
      storedStudents = JSON.parse(localStorage.getItem("students") || "[]")
      console.log("Available students after setup:", storedStudents)

      // Find student with matching username and password
      console.log("Checking credentials for:", username)

      // Check if the student exists by username first
      const studentByUsername = storedStudents.find((s) => s.username === username)

      if (!studentByUsername) {
        console.log("Student not found with username:", username)
        throw new Error("Student not found. Please check your username.")
      }

      // Then check if the password matches
      if (studentByUsername.password !== password) {
        console.log("Password doesn't match for student:", username)
        throw new Error("Incorrect password. Please try again.")
      }

      // If we get here, both username and password are correct
      console.log("Login successful for student:", studentByUsername.name)

      // Store current student username for tracking game performance
      localStorage.setItem("currentStudent", username)

      // Update last active time
      const updatedStudents = storedStudents.map((s) => {
        if (s.username === username) {
          return {
            ...s,
            lastActive: "Today",
          }
        }
        return s
      })
      localStorage.setItem("students", JSON.stringify(updatedStudents))

      toast({
        title: "Login successful",
        description: `Welcome, ${studentByUsername.name}! Let's play and learn!`,
      })

      // Navigate to dashboard
      router.push("/student/dashboard")
    } catch (error) {
      console.error("Login error:", error)
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Please check your login details",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-purple-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-4 border-blue-400 shadow-2xl">
        <CardHeader className="bg-blue-400 text-white text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=80&width=80"
                alt="Student avatar"
                width={80}
                height={80}
                className="rounded-full"
              />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Student Login</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-lg">
                Username
              </Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="h-14 text-lg rounded-xl"
                placeholder="Enter your username"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-lg">
                Password
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-14 text-lg rounded-xl"
                placeholder="Enter your password"
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full h-16 text-xl bg-blue-500 hover:bg-blue-600 rounded-xl"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : "Let's Play!"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600 mb-2">Demo credentials:</p>
            <p className="text-sm text-gray-500">Username: student</p>
            <p className="text-sm text-gray-500">Password: password</p>
          </div>

          <div className="mt-8 flex justify-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-red-400 animate-bounce"></div>
            <div className="w-12 h-12 rounded-full bg-yellow-400 animate-bounce delay-100"></div>
            <div className="w-12 h-12 rounded-full bg-green-400 animate-bounce delay-200"></div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

